import streamlit as st
from datetime import datetime, date
import io
import requests
import json
import mysql.connector
import hashlib
import uuid
from supabase import create_client
import base64
from jinja2 import Template
from PIL import Image as PILImage, ImageDraw, ImageFont
import time
import tempfile
import os
from pathlib import Path
import re
import asyncio
import sys
import traceback
from playwright.async_api import async_playwright
import threading
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
import string

# Cache a shared holder for Playwright objects across reruns
@st.cache_resource
def get_playwright_holder():
    return {}

# =============================================================================
# PERFORMANCE OPTIMIZATIONS - DATABASE CONNECTION POOL
# =============================================================================

from mysql.connector import pooling
import threading
from functools import lru_cache
from datetime import datetime, timedelta

# Global connection pool
_connection_pool = None
_pool_lock = threading.Lock()

# Cache configuration
CACHE_TTL = 300  # 5 minutes

# In-memory cache for frequently accessed data
class CacheManager:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._cache = {}
            return cls._instance
    
    def get(self, key):
        if key not in self._cache:
            return None
        
        value, expiry = self._cache[key]
        if datetime.now() > expiry:
            del self._cache[key]
            return None
            
        return value
    
    def set(self, key, value, ttl=CACHE_TTL):
        self._cache[key] = (value, datetime.now() + timedelta(seconds=ttl))
    
    def clear(self, key_prefix=None):
        if key_prefix is None:
            self._cache.clear()
        else:
            self._cache = {k: v for k, v in self._cache.items() if not k.startswith(key_prefix)}

# Initialize cache
cache = CacheManager()

# Cache decorator with TTL
def cached(ttl=CACHE_TTL, key_prefix='cache_'):
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Create cache key
            cache_key = f"{key_prefix}{func.__name__}_{str(args)}_{str(kwargs)}"
            
            # Try to get from cache
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                return cached_result
                
            # If not in cache, compute and store
            result = func(*args, **kwargs)
            if result is not None:  # Only cache non-None results
                cache.set(cache_key, result, ttl)
            return result
        return wrapper
    return decorator

def get_db_connection(max_retries=2):
    """Get MySQL database connection from pool - OPTIMIZED VERSION"""
    global _connection_pool
    
    if _connection_pool is None:
        with _pool_lock:
            if _connection_pool is None:
                try:
                    _connection_pool = pooling.MySQLConnectionPool(
                        pool_name="dexa_pool",
                        pool_size=10,  # Reduced from 10
                        pool_reset_session=True,
                        host=st.secrets["MYSQL_HOST"],
                        user=st.secrets["MYSQL_USER"],
                        password=st.secrets["MYSQL_PASSWORD"],
                        database=st.secrets["MYSQL_DATABASE"],
                        port=st.secrets.get("MYSQL_PORT", 3306),
                        connect_timeout=30,  # Reduced from 5s
                        buffered=True,
                        use_pure=True,
                        autocommit=True,
                        connection_timeout=30,
                        read_timeout=60,
                        write_timeout=60
                    )
                except Exception as e:
                    st.error(f"❌ Database connection failed: {e}")
                    return None
    
    # Simple connection retrieval without complex retry logic
    try:
        conn = _connection_pool.get_connection()
        # Quick connection test
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        return conn
    except Exception:
        return None

def check_database_health():
    """Quick database health check"""
    start_time = time.time()
    try:
        conn = get_db_connection()
        if not conn:
            return False, "Failed to get database connection"
            
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        
        response_time = (time.time() - start_time) * 1000
        if response_time > 1000:
            return True, f"⚠️ Database response slow: {response_time:.2f}ms"
        return True, f"✅ Database healthy ({response_time:.2f}ms)"
        
    except Exception as e:
        return False, f"❌ Database error: {str(e)}"

def perform_quick_health_check():
    """Quick system health check"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        return True
    except:
        return False

# =============================================================================
# ENHANCED EMAIL NOTIFICATION SYSTEM WITH USER REGISTRATION
# =============================================================================
class EmailNotificationSystem:
    def __init__(self):
        self.smtp_server = st.secrets.get("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = st.secrets.get("SMTP_PORT", 587)
        self.sender_email = st.secrets.get("SMTP_EMAIL")
        self.sender_password = st.secrets.get("SMTP_PASSWORD")
        self.app_url = st.secrets.get("APP_URL", "http://localhost:8501")
        
        # Debug information
        self._show_config_status()
    
    def _show_config_status(self):
        """Show email configuration status"""
        if not self.sender_email or not self.sender_password:
            st.sidebar.warning("⚠️ Email credentials missing from secrets.toml")
            st.sidebar.info("Please check your SMTP_EMAIL and SMTP_PASSWORD in secrets.toml")
        else:
            st.sidebar.success("✅ Email credentials loaded")
    
    def test_connection(self):
        """Test SMTP connection and return detailed results"""
        try:
            if not self.sender_email or not self.sender_password:
                return False, "Email credentials not configured"
            
            st.info("🔍 Testing email configuration...")
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
            
            return True, "✅ Email configuration test successful!"
            
        except smtplib.SMTPAuthenticationError:
            return False, "❌ Gmail authentication failed. Please verify:\n1. You're using an App Password (not your regular Gmail password)\n2. 2-Factor Authentication is enabled\n3. The App Password is correct"
        except Exception as e:
            return False, f"❌ Connection failed: {str(e)}"
    
    def send_user_credentials(self, user_data, hospital_info, temp_password):
        """Send login credentials to new user via email"""
        try:
            # Validate configuration
            if not all([self.sender_email, self.sender_password]):
                return False, "Email configuration incomplete"
            
            if not user_data.get('email'):
                return False, "User email address not provided"
            
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = f"Your DEXA Report System Account - {hospital_info['hospital_name']}"
            message["From"] = self.sender_email
            message["To"] = user_data['email']
            
            # Create HTML email content
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                    .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }}
                    .content {{ background: #f9f9f9; padding: 20px; border-radius: 0 0 10px 10px; }}
                    .credentials {{ background: white; padding: 15px; border-left: 4px solid #667eea; margin: 15px 0; }}
                    .footer {{ text-align: center; margin-top: 20px; font-size: 12px; color: #666; }}
                    .warning {{ background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; border-radius: 5px; margin: 10px 0; }}
                    .button {{ background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🏥 DEXA Report System</h1>
                        <h2>Your Account is Ready</h2>
                    </div>
                    <div class="content">
                        <p>Dear <strong>{user_data['full_name']}</strong>,</p>
                        
                        <p>An account has been created for you in the DEXA Report System at <strong>{hospital_info['hospital_name']}</strong>.</p>
                        
                        <div class="credentials">
                            <h3>🔐 Your Login Credentials:</h3>
                            <p><strong>Username:</strong> {user_data['username']}</p>
                            <p><strong>Temporary Password:</strong> <code style="background: #f4f4f4; padding: 5px 10px; border-radius: 3px; font-size: 16px;">{temp_password}</code></p>
                            <p><strong>Login URL:</strong> <a href="{self.app_url}" class="button">Access DEXA System</a></p>
                        </div>
                        
                        <div class="warning">
                            <strong>⚠️ Important Security Notice:</strong>
                            <ul>
                                <li>This is a temporary password</li>
                                <li>Please change your password after first login</li>
                                <li>Keep your credentials secure and confidential</li>
                                <li>Do not share your password with anyone</li>
                            </ul>
                        </div>
                        
                        <p><strong>Hospital Information:</strong></p>
                        <ul>
                            <li><strong>Hospital:</strong> {hospital_info['hospital_name']}</li>
                            <li><strong>Address:</strong> {hospital_info['address']}</li>
                            <li><strong>Phone:</strong> {hospital_info['phone_number']}</li>
                            <li><strong>Email:</strong> {hospital_info['email']}</li>
                        </ul>
                        
                        <p>If you have any questions or need assistance, please contact your hospital administrator.</p>
                        
                        <p>Best regards,<br>
                        <strong>{hospital_info['hospital_name']} Administration</strong></p>
                    </div>
                    <div class="footer">
                        <p>This is an automated message. Please do not reply to this email.</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Plain text version
            text_content = f"""
            DEXA Report System - Account Credentials
            
            Dear {user_data['full_name']},
            
            An account has been created for you in the DEXA Report System at {hospital_info['hospital_name']}.
            
            YOUR LOGIN CREDENTIALS:
            Username: {user_data['username']}
            Temporary Password: {temp_password}
            Login URL: {self.app_url}
            
            IMPORTANT SECURITY NOTICE:
            - This is a temporary password
            - Please change your password after first login
            - Keep your credentials secure and confidential
            - Do not share your password with anyone
            
            Hospital Information:
            - Hospital: {hospital_info['hospital_name']}
            - Address: {hospital_info['address']}
            - Phone: {hospital_info['phone_number']}
            - Email: {hospital_info['email']}
            
            If you have any questions, please contact your hospital administrator.
            
            Best regards,
            {hospital_info['hospital_name']} Administration
            
            This is an automated message. Please do not reply to this email.
            """
            
            # Add both HTML and plain text parts
            message.attach(MIMEText(text_content, "plain"))
            message.attach(MIMEText(html_content, "html"))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
            
            return True, f"✅ Credentials sent successfully to {user_data['email']}"
            
        except smtplib.SMTPAuthenticationError:
            return False, "❌ Gmail authentication failed. Please use App Passwords (16-character code) instead of your regular password."
        except Exception as e:
            return False, f"❌ Failed to send email: {str(e)}"
    
    def send_admin_notification(self, admin_data, new_user_data, hospital_info):
        """Send notification to admin about new user registration"""
        try:
            if not all([self.sender_email, self.sender_password]):
                return False, "Email configuration incomplete"
            
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = f"New User Registration - {hospital_info['hospital_name']}"
            message["From"] = self.sender_email
            message["To"] = admin_data.get('email', hospital_info['email'])
            
            # Create HTML email content
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                    .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }}
                    .content {{ background: #f9f9f9; padding: 20px; border-radius: 0 0 10px 10px; }}
                    .user-info {{ background: white; padding: 15px; border-left: 4px solid #28a745; margin: 15px 0; }}
                    .footer {{ text-align: center; margin-top: 20px; font-size: 12px; color: #666; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🏥 DEXA Report System</h1>
                        <h2>New User Registration</h2>
                    </div>
                    <div class="content">
                        <p>Dear <strong>{admin_data.get('full_name', 'Administrator')}</strong>,</p>
                        
                        <p>A new user has been registered in the DEXA Report System at <strong>{hospital_info['hospital_name']}</strong>.</p>
                        
                        <div class="user-info">
                            <h3>👤 New User Details:</h3>
                            <p><strong>Full Name:</strong> {new_user_data['full_name']}</p>
                            <p><strong>Username:</strong> {new_user_data['username']}</p>
                            <p><strong>Email:</strong> {new_user_data.get('email', 'Not provided')}</p>
                            <p><strong>Mobile:</strong> {new_user_data.get('mobile_number', 'Not provided')}</p>
                            <p><strong>User Type:</strong> {new_user_data.get('user_type', 'user').title()}</p>
                            <p><strong>Registration Date:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
                        </div>
                        
                        <p>You can manage this user's account and permissions through the admin dashboard.</p>
                        
                        <p><strong>Login to Admin Dashboard:</strong> <a href="{self.app_url}" style="background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Access Admin Panel</a></p>
                        
                        <p>Best regards,<br>
                        <strong>DEXA Report System</strong></p>
                    </div>
                    <div class="footer">
                        <p>This is an automated message. Please do not reply to this email.</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Plain text version
            text_content = f"""
            DEXA Report System - New User Registration
            
            Dear {admin_data.get('full_name', 'Administrator')},
            
            A new user has been registered in the DEXA Report System at {hospital_info['hospital_name']}.
            
            NEW USER DETAILS:
            Full Name: {new_user_data['full_name']}
            Username: {new_user_data['username']}
            Email: {new_user_data.get('email', 'Not provided')}
            Mobile: {new_user_data.get('mobile_number', 'Not provided')}
            User Type: {new_user_data.get('user_type', 'user').title()}
            Registration Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}
            
            You can manage this user's account and permissions through the admin dashboard.
            
            Login URL: {self.app_url}
            
            Best regards,
            DEXA Report System
            
            This is an automated message. Please do not reply to this email.
            """
            
            # Add both HTML and plain text parts
            message.attach(MIMEText(text_content, "plain"))
            message.attach(MIMEText(html_content, "html"))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
            
            return True, "✅ Admin notification sent successfully"
            
        except Exception as e:
            return False, f"❌ Failed to send admin notification: {str(e)}"

def generate_secure_password(length=10):
    """Generate a secure temporary password"""
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = '!@#$%&*'
    
    # Ensure at least one character from each set
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(special)
    ]
    
    # Fill the rest with random choices from all sets
    all_chars = lowercase + uppercase + digits + special
    password.extend(random.choice(all_chars) for _ in range(length - 4))
    
    # Shuffle the password
    random.shuffle(password)
    
    return ''.join(password)

def generate_memorable_password():
    """Generate a memorable but secure password"""
    adjectives = ['Happy', 'Swift', 'Bright', 'Calm', 'Clear', 'Wise', 'Bold', 'Safe']
    nouns = ['Tiger', 'Eagle', 'River', 'Stone', 'Cloud', 'Star', 'Tree', 'Wave']
    numbers = ''.join(random.choices(string.digits, k=2))
    special = random.choice('!@#$%&*')
    
    return f"{random.choice(adjectives)}{random.choice(nouns)}{numbers}{special}"

# =============================================================================
# OPTIMIZED PLAYWRIGHT PDF GENERATOR - FIXED VERSION
# =============================================================================
class OptimizedPlaywrightPDFGenerator:
    def __init__(self):
        # Create a static directory structure for images
        self.static_dir = Path("static")
        self.images_dir = self.static_dir / "images"
        self.templates = Path("templates")
        
        # Create directories if they don't exist
        self.images_dir.mkdir(parents=True, exist_ok=True)
        
        # Store your static images in these paths
        self.static_images = {
            'vital_insights_logo': self.images_dir / "vital_insights_logo.png",
            'fingerprint_icon': self.images_dir / "fingerprint_icon.png",
            'body_outline': self.images_dir / "body_outline.png",
            'ap_spine_placeholder': self.images_dir / "ap_spine_placeholder.png",
            'left_femur': self.images_dir / "left_femur.png",
            'right_femur': self.images_dir / "right_femur.png",
            'fat_distribution_placeholder': self.images_dir / "fat_distribution_placeholder.png",
        }
        
        # Create placeholder images if they don't exist
        self._setup_static_images()
        self.template_file = self.templates / "a.html"
        self.html_template = self._load_html_template()
        
        # Initialize Supabase storage
        self.supabase_storage = SupabaseStorageManager()
        self.bucket_name = self.supabase_storage.bucket_name
        # Set base URL for images
        self._setup_base_urls()
        
        # Initialize Playwright with locking
        self.playwright = None
        self._browser_instance = None
        self._browser_lock = asyncio.Lock()
        self.initialized = False

    async def _get_browser(self):
        """Get or create browser instance with local file access enabled - FIXED VERSION"""
        async with self._browser_lock:
            holder = get_playwright_holder()

            # Check if we have a valid browser instance
            if 'browser' in holder and holder['browser']:
                try:
                    # Test if the browser is still alive
                    browser = holder['browser']
                    # Try to create a page to test browser connectivity
                    page = await browser.new_page()
                    await page.close()
                    self._browser_instance = browser
                    self.playwright = holder.get('playwright')
                    return self._browser_instance
                except Exception:
                    # Browser is dead, clean up and recreate
      
                    if 'browser' in holder:
                        try:
                            await holder['browser'].close()
                        except:
                            pass
                    if 'playwright' in holder:
                        try:
                            await holder['playwright'].stop()
                        except:
                            pass
                    holder.clear()

            # Create new browser instance
            try:
                if 'playwright' not in holder or holder['playwright'] is None:
                    holder['playwright'] = await async_playwright().start()
                
                self.playwright = holder['playwright']
                
                # Launch Chromium with flags that allow local file access
                holder['browser'] = await self.playwright.chromium.launch(
                    headless=True,
                    args=[
                        '--no-sandbox',
                        '--disable-setuid-sandbox',
                        '--disable-web-security',  # Important for local file access
                        '--allow-file-access-from-files',  # Allow file:// URLs
                        '--allow-running-insecure-content',
                        '--disable-features=VizDisplayCompositor',
                        '--disable-dev-shm-usage',
                        '--disable-gpu',
                    ]
                )
                
                self._browser_instance = holder['browser']
                self.initialized = True
                return self._browser_instance
                
            except Exception as e:
                st.error(f"❌ Failed to create browser instance: {str(e)}")
                # Clean up on failure
                if 'playwright' in holder:
                    try:
                        await holder['playwright'].stop()
                    except:
                        pass
                    holder.clear()
                raise

    async def _generate_pdf_async_optimized(self, html_content, page_size='A4'):
        """Optimized async PDF generation - FIXED VERSION"""
        browser = None
        page = None
        try:
            browser = await self._get_browser()
            page = await browser.new_page()
            
            # Set longer timeout for content loading
            page.set_default_timeout(60000)  # 60 seconds
            
            await page.set_content(html_content, wait_until='networkidle')
            
            # Simplified PDF options
            pdf_bytes = await page.pdf(
                format=page_size, 
                print_background=True,
                margin={'top': '0.5in', 'right': '0.5in', 'bottom': '0.5in', 'left': '0.5in'}
            )
            return pdf_bytes
            
        except Exception as e:
            st.error(f"❌ Error in PDF generation: {str(e)}")
            # Clean up the browser instance on error
            holder = get_playwright_holder()
            if 'browser' in holder:
                try:
                    await holder['browser'].close()
                except:
                    pass
            if 'playwright' in holder:
                try:
                    await holder['playwright'].stop()
                except:
                    pass
            holder.clear()
            return None
        finally:
            if page:
                await page.close()

    def generate_pdf_with_timeout(self, report_data, page_size='A4', timeout=30):
        """Generate PDF with timeout protection - FIXED VERSION"""
        try:
            # Convert all decimal values to float
            def convert_to_float(value):
                if value is None:
                    return 0.0
                try:
                    if hasattr(value, 'quantize'):
                        return float(value)
                    return float(value)
                except (ValueError, TypeError):
                    return 0.0
            
            # Convert all numeric values in report_data to float
            converted_report_data = {}
            for key, value in report_data.items():
                if isinstance(value, (int, float, str)) and str(value).replace('.', '').replace('-', '').isdigit():
                    converted_report_data[key] = convert_to_float(value)
                else:
                    converted_report_data[key] = value
            
            report_data = converted_report_data
            
            # Pre-render template outside async context
            html_content = self._prerender_template(report_data)
            
            # Run async function with timeout
            async def _generate_with_cleanup():
                try:
                    return await self._generate_pdf_async_optimized(html_content, page_size)
                except Exception as e:
                    st.error(f"❌ PDF generation failed: {str(e)}")
                    return None

            def _run_with_timeout(coro, timeout_sec):
                return asyncio.run(asyncio.wait_for(coro, timeout=timeout_sec))

            try:
                return _run_with_timeout(_generate_with_cleanup(), timeout)
            except asyncio.TimeoutError:
                st.error("PDF generation timed out. Please try again.")
                # Clean up on timeout
                holder = get_playwright_holder()
                if 'browser' in holder:
                    try:
                        asyncio.run(holder['browser'].close())
                    except:
                        pass
                if 'playwright' in holder:
                    try:
                        asyncio.run(holder['playwright'].stop())
                    except:
                        pass
                holder.clear()
                return None
            except NotImplementedError as ne:
                # On some Windows hosts the default event loop/policy doesn't support subprocesses
                if sys.platform.startswith("win") or os.name == 'nt':
                    st.warning("Detected event loop without subprocess support; switching to WindowsProactorEventLoopPolicy and retrying...")
                    try:
                        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
                    except Exception:
                        st.text(traceback.format_exc())
                    try:
                        return _run_with_timeout(_generate_with_cleanup(), timeout)
                    except Exception:
                        st.text(traceback.format_exc())
                        return None
                else:
                    # Re-raise for non-Windows platforms
                    raise
            
        except Exception as e:
            # Show full traceback to the UI to help debugging
            tb = traceback.format_exc()
            st.error(f"❌ Error in PDF generation: {str(e)}")
            st.text(tb)

            # If this is caused by a running event loop (common in some hosting environments),
            # try using an alternate approach for running async code
            if 'asyncio.run() cannot be called from a running event loop' in str(e):
                try:
                    # Create a new event loop and run the coroutine there
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(asyncio.wait_for(
                        _generate_with_cleanup(),
                        timeout=timeout
                    ))
                    loop.close()
                    return result
                except Exception:
                    st.text(traceback.format_exc())

            return None

    # ... rest of the class methods remain the same ...

    async def close_playwright(self):
        """Close Playwright browser instance"""
        if self._browser_instance:
            await self._browser_instance.close()
        if self.playwright:
            await self.playwright.stop()
        self._browser_instance = None
        self.initialized = False

    def _load_html_template(self):
        """Load HTML template from external file"""
        try:
            if self.template_file.exists():
                with open(self.template_file, 'r', encoding='utf-8') as file:
                    template_content = file.read()
                return Template(template_content)
            else:
                # Fallback to embedded template if file doesn't exist
                st.warning(f"⚠️ Template file not found at {self.template_file}. Using embedded template.")
                return self._get_fallback_template()
        except Exception as e:
            st.error(f"❌ Error loading template: {str(e)}")
            return self._get_fallback_template()

    def _get_fallback_template(self):
        """Fallback HTML template"""
        return Template("""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>DEXA Report</title>
            <style>
                body { font-family: Arial, sans-serif; }
                .header { text-align: center; margin-bottom: 20px; }
                .section { margin-bottom: 15px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>DEXA Report for {{ patient_name }}</h1>
            </div>
            <div class="section">
                <p><strong>Report ID:</strong> {{ report_id }}</p>
                <p><strong>Date:</strong> {{ report_date }}</p>
            </div>
        </body>
        </html>
        """)

    def _setup_base_urls(self):
        """Setup proper base URLs for images using absolute file paths"""
        try:
            self.base_image_urls = {}
            
            # Create static directory structure
            self.static_dir = Path("static")
            self.images_dir = self.static_dir / "images"
            self.images_dir.mkdir(parents=True, exist_ok=True)
            
            # Define static images with proper paths
            self.static_images = {
                'vital_insights_logo': self.images_dir / "vital_insights_logo.png",
                'fingerprint_icon': self.images_dir / "fingerprint_icon.png",
                'body_outline': self.images_dir / "body_outline.png",
                'ap_spine_placeholder': self.images_dir / "ap_spine_placeholder.png",
                'left_femur': self.images_dir / "left_femur.png",
                'right_femur': self.images_dir / "right_femur.png",
                'fat_distribution_placeholder': self.images_dir / "fat_distribution_placeholder.png",
            }
            
            # Create placeholder images if they don't exist
            self._setup_static_images()
            
            # Use absolute file paths for local images
            for key, image_path in self.static_images.items():
                if image_path.exists():
                    # Use absolute path that Playwright can access
                    abs_path = image_path.absolute()
                    # Use file:// URL for local file access
                    file_url = f"file://{abs_path}"
                    self.base_image_urls[f"{key}_url"] = file_url
                else:
                    # Create the placeholder and use it
                    self._create_placeholder_image(image_path, key)
                    abs_path = image_path.absolute()
                    file_url = f"file://{abs_path}"
                    self.base_image_urls[f"{key}_url"] = file_url
            
        except Exception as e:
            st.error(f"❌ Error setting up image URLs: {str(e)}")
            # Fallback to base64 embedded images
            self._setup_base64_fallback()

    def _setup_base64_fallback(self):
        """Setup base64 encoded images as ultimate fallback"""
        try:
            self.base_image_urls = {}
            
            # Generate base64 placeholders for all required images
            image_types = [
                'vital_insights_logo', 'fingerprint_icon', 'body_outline',
                'ap_spine_placeholder', 'left_femur', 'right_femur','fat_distribution_placeholder'
            ]
            
            for image_type in image_types:
                base64_data = self._get_base64_placeholder(image_type)
                self.base_image_urls[f"{image_type}_url"] = base64_data
                
            st.warning("⚠️ Using base64 fallback images for PDF generation")
            
        except Exception as e:
            st.error(f"❌ Base64 fallback also failed: {str(e)}")

    def _prerender_template(self, report_data):
        """Pre-render template with reliable image URLs - CORRECTED PAGE MAPPING"""
        # Get uploaded images from database
        stored_images = self._get_report_images_for_pdf(report_data['report_id'])
        
        # Convert ALL images to base64 data URLs for maximum reliability
        image_urls = {}
        
        # Process uploaded medical images - use base64 for reliability
        medical_image_types = ['ap_spine', 'right_femur', 'left_femur', 'body_outline', 'fat_distribution']
        
        for img_type in medical_image_types:
            if stored_images.get(img_type):
                try:
                    image_bytes = stored_images[img_type].getvalue()
                    base64_data = base64.b64encode(image_bytes).decode('utf-8')
                    
                    # Detect image format
                    if image_bytes.startswith(b'\x89PNG'):
                        mime_type = 'image/png'
                    elif image_bytes.startswith(b'\xff\xd8'):
                        mime_type = 'image/jpeg'
                    else:
                        mime_type = 'image/jpeg'  # default
                    
                    image_urls[img_type] = f"data:{mime_type};base64,{base64_data}"
                    st.success(f"✅ Processed {img_type} image for PDF")
                    
                except Exception as e:
                    st.warning(f"⚠️ Could not process {img_type} image: {str(e)}")
                    # Use static placeholder as fallback
                    image_urls[img_type] = self._get_base64_placeholder(img_type)
            else:
                # Use static placeholder image
                st.warning(f"⚠️ No {img_type} image found, using placeholder")
                image_urls[img_type] = self._get_base64_placeholder(img_type)
        
        # Process static images (logo, icons, etc.) - use base64 for consistency
        static_images_mapping = {
            'vital_insights_logo_url': 'vital_insights_logo',
            'fingerprint_icon_url': 'fingerprint_icon',
            'body_outline_image_url': 'body_outline',  # For page 5
            'ap_spine_placeholder_url': 'ap_spine_placeholder',
            'left_femur_url': 'left_femur',
            'right_femur_url': 'right_femur',
            'fat_distribution_placeholder_url': 'fat_distribution_placeholder'
        }
        
        for url_key, image_name in static_images_mapping.items():
            try:
                image_urls[url_key] = self._get_static_image_as_base64(image_name)
            except Exception as e:
                st.error(f"❌ Error loading static image {image_name}: {str(e)}")
                image_urls[url_key] = self._get_base64_placeholder(image_name)
        
        # Generate assessments and recommendations
        assessments = self._generate_assessments(report_data)
        recommendations = self._generate_recommendations(report_data)
        regional_data = self._calculate_regional_totals(report_data)
        
        # Prepare template data with ALL image URLs - CORRECTED PAGE MAPPING
        template_data = {
            'patient_name': report_data.get('patient_name', 'BRI.K'),
            'patient_id': report_data.get('patient_id', '000480'),
            'report_id': report_data.get('report_id', '000653'),
            'report_date': report_data.get('report_date', '17 SEP 2025'),
            'age': report_data.get('age', 36),
            'gender': report_data.get('gender', 'M'),
            'height': report_data.get('height', 171),
            'total_mass': report_data.get('total_mass', 104.6),
            'fat_mass': report_data.get('fat_mass', 39.79),
            'lean_mass': report_data.get('lean_mass', 61.84),
            'bone_mass': report_data.get('bone_mass', 2.94),
            'body_fat_percentage': report_data.get('body_fat_percentage', 38.0),
            'muscle_mass_almi': report_data.get('muscle_mass_almi', 10.23),
            'bone_density_t_score': report_data.get('bone_density_t_score', -0.6),
            'visceral_fat_area': report_data.get('visceral_fat_area', 170.0),
            'ag_ratio': report_data.get('ag_ratio', 1.23),
            'ffmi': report_data.get('ffmi', 20.67),
            'fracture_risk': report_data.get('fracture_risk', 'LOW'),
            'muscle_loss_risk': report_data.get('muscle_loss_risk', 'LOW'),
            'z_score': report_data.get('z_score', -0.6),
            
            # ========== CORRECTED PAGE MAPPING ==========
            
            # Page 1 & 2 Images (Header/Logo)
            'vital_insights_logo_url': image_urls['vital_insights_logo_url'],
            'fingerprint_icon_url': image_urls['fingerprint_icon_url'],
            
            # Page 3 Images (Medical Scans)
            'ap_spine_image_url': image_urls['ap_spine'],
            'right_femur_image_url': image_urls['right_femur'], 
            'left_femur_image_url': image_urls['left_femur'],
            
            # Page 4 Images (Fat Distribution) - CORRECTED
            'fat_distribution_image_url': image_urls['fat_distribution'],
            
            # Page 5 Images (Body Composition) 
            'body_outline_image_url': image_urls['body_outline'],
            
            # Page 6 Images (Risk Assessment)
            'fingerprint_icon_url_page6': image_urls['fingerprint_icon_url'],  # Duplicate for page 6
            
            # Static placeholder URLs (for template compatibility)
            
            'ap_spine_placeholder_url': image_urls['ap_spine_placeholder_url'],
            'left_femur_url': image_urls['left_femur_url'],
            'right_femur_url': image_urls['right_femur_url'],
            'fat_distribution_placeholder_url': image_urls['fat_distribution_placeholder_url'],
            
            # ============================================
            
            # Measurements data
            'ap_spine_measurements': report_data.get('ap_spine_measurements', []),
            'right_femur_measurements': report_data.get('right_femur_measurements', []),
            'left_femur_measurements': report_data.get('left_femur_measurements', []),
            
            **assessments,
            **recommendations,
            **regional_data
        }
        
        # Debug: Show which images are being used for which pages
        st.info("📄 Page-by-Page Image Mapping:")
        page_mapping = {
            "Page 1-2 (Header)": ["vital_insights_logo_url", "fingerprint_icon_url"],
            "Page 3 (Medical Scans)": ["ap_spine_image_url", "right_femur_image_url", "left_femur_image_url"],
            "Page 4 (Fat Distribution)": ["fat_distribution_image_url"],
            "Page 5 (Body Composition)": ["body_outline_image_url"],
            "Page 6 (Risk Assessment)": ["fingerprint_icon_url_page6"]
        }
        
        for page, images in page_mapping.items():
            status = "✅" if all(template_data.get(img) for img in images) else "❌"
            st.write(f"{status} {page}: {', '.join(images)}")
        
        # Render HTML template
        html_content = self.html_template.render(**template_data)
        
        # Debug: Check if specific images are in the rendered HTML
        debug_images = {
            'Page 4 - Fat Distribution': 'fat_distribution_image_url',
            'Page 5 - Body Outline': 'body_outline_image_url', 
            'Page 6 - Fingerprint': 'fingerprint_icon_url_page6'
        }
        
        for page_desc, img_var in debug_images.items():
            if img_var in template_data and template_data[img_var]:
                if f'"{template_data[img_var]}"' in html_content:
                    st.success(f"✅ {page_desc}: Image found in HTML")
                else:
                    st.error(f"❌ {page_desc}: Image variable exists but not in rendered HTML")
            else:
                st.error(f"❌ {page_desc}: Image variable missing from template data")
        
        return html_content

    def _get_static_image_url(self, image_name):
        """Get static image URL - prefer file://, fallback to base64"""
        try:
            image_path = self.static_images.get(image_name)
            if image_path and image_path.exists():
                # Use file:// URL for local file access
                abs_path = image_path.absolute()
                return f"file://{abs_path}"
            else:
                # Create placeholder and use it
                self._create_placeholder_image(image_path, image_name)
                abs_path = image_path.absolute()
                return f"file://{abs_path}"
        except Exception as e:
            # Ultimate fallback to base64
            return self._get_base64_placeholder(image_name)

    def _setup_static_images(self):
        """Setup static images - create all required placeholder images"""
        for image_name, image_path in self.static_images.items():
            if not image_path.exists():
                self._create_placeholder_image(image_path, image_name)

    def _create_placeholder_image(self, image_path, image_name, size=(200, 100), color=(255, 107, 61)):
        """Create a high-quality placeholder image for testing"""
        try:
            # Customize placeholder based on image type
            sizes = {
                'vital_insights_logo': (180, 60),
                'fingerprint_icon': (60, 60),
                'body_outline': (130, 280),
                'ap_spine_placeholder': (90, 130),
                'left_femur': (90, 130),
                'right_femur': (90, 130),
                'fat_distribution_placeholder': (80, 120)
            }
            
            colors = {
                'vital_insights_logo': (255, 107, 61),  # Orange
                'fingerprint_icon': (255, 107, 61),     # Orange
                'body_outline': (100, 100, 100),        # Gray
                'ap_spine_placeholder': (200, 200, 200), # Light gray
                'left_femur': (200, 200, 200),   # Light gray
                'right_femur': (200, 200, 200),  # Light gray
                'fat_distribution_placeholder': (255, 150, 100) # Light orange
            }
            
            texts = {
                'vital_insights_logo': "Vital Insights",
                'fingerprint_icon': "🔒",
                'body_outline': "Body Outline",
                'ap_spine_placeholder': "AP-Spine",
                'left_femur': "Left Femur",
                'right_femur': "Right Femur",
                'fat_distribution_placeholder': "Fat Distribution"
            }
            
            width, height = sizes.get(image_name, size)
            color = colors.get(image_name, color)
            text = texts.get(image_name, image_name.replace('_', ' ').title())
            
            # Create image with white background
            img = PILImage.new('RGB', (width, height), color=(255, 255, 255))
            draw = ImageDraw.Draw(img)
            
            # Draw colored rectangle with border
            draw.rectangle([2, 2, width-2, height-2], fill=color, outline=(0, 0, 0), width=1)
            
            # Add text
            try:
                # Try to use a larger font
                font_size = min(width // 8, height // 4, 20)
                font = ImageFont.truetype("arial.ttf", font_size) if sys.platform == "win32" else ImageFont.load_default()
                
                # Calculate text position
                bbox = draw.textbbox((0, 0), text, font=font)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                x = (width - text_width) // 2
                y = (height - text_height) // 2
                
                # Add text shadow for better visibility
                shadow_color = (0, 0, 0) if sum(color) > 384 else (255, 255, 255)
                draw.text((x+1, y+1), text, fill=shadow_color, font=font)
                draw.text((x, y), text, fill=(255, 255, 255), font=font)
                
            except:
                # Fallback without specific font
                x = width // 6
                y = height // 2 - 10
                draw.text((x, y), text, fill=(255, 255, 255))
            
            # Ensure directory exists
            image_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Save as high-quality PNG
            img.save(image_path, format='PNG', optimize=True)
            
        except Exception as e:
            st.error(f"❌ Error creating placeholder {image_name}: {str(e)}")

    def _process_uploaded_image_optimized(self, uploaded_file, target_width, target_height):
        """Optimized image processing"""
        if uploaded_file is None:
            return None
        
        try:
            # Use smaller thumbnail for faster processing
            image = PILImage.open(io.BytesIO(uploaded_file.getvalue()))
            
            # Convert to RGB quickly
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Create smaller thumbnail for PDF (reduced quality for speed)
            image.thumbnail((target_width, target_height), PILImage.Resampling.LANCZOS)
            
            # Save with lower quality for faster processing
            temp_file = io.BytesIO()
            image.save(temp_file, format='JPEG', quality=80, optimize=True)
            temp_file.seek(0)
            
            return temp_file
            
        except Exception:
            return None

    def _get_report_images_for_pdf(self, report_id):
        """Get stored images for PDF generation with better error handling"""
        conn = get_db_connection()
        if not conn:
            st.error("❌ Database connection failed for image retrieval")
            return {}
        
        cursor = conn.cursor(dictionary=True)
        try:
            cursor.execute("SELECT image_type, image_data FROM report_images WHERE report_id = %s", (report_id,))
            images = cursor.fetchall()
            
            image_dict = {}
            for img in images:
                if img['image_data']:
                    try:
                        image_data = base64.b64decode(img['image_data'])
                        image_file = io.BytesIO(image_data)
                        image_dict[img['image_type']] = image_file
                        st.success(f"✅ Retrieved {img['image_type']} image from database")
                    except Exception as e:
                        st.error(f"❌ Error decoding image {img['image_type']}: {str(e)}")
                        image_dict[img['image_type']] = None
                else:
                    st.warning(f"⚠️ No image data for {img['image_type']}")
            
            return image_dict
        except Exception as e:
            st.error(f"❌ Error retrieving images: {str(e)}")
            return {}
        finally:
            cursor.close()
            conn.close()
    def _save_report_images(self, report_id, image_data):
        """Save images to database - ENHANCED VERSION"""
        conn = None
        cursor = None
        
        try:
            conn = get_db_connection()
            if not conn:
                st.error("❌ Database connection failed for image saving")
                return False
            
            cursor = conn.cursor()
            images_saved = 0
            
            # First, delete any existing images for this report to avoid duplicates
            cursor.execute("DELETE FROM report_images WHERE report_id = %s", (report_id,))
            
            for image_type, image_file in image_data.items():
                if image_file is not None:
                    try:
                        # Get image bytes
                        image_bytes = image_file.getvalue()
                        
                        # Verify it's a valid image
                        try:
                            PILImage.open(io.BytesIO(image_bytes))
                            st.success(f"✅ Valid {image_type} image detected ({len(image_bytes)} bytes)")
                        except Exception as e:
                            st.warning(f"⚠️ Invalid image for {image_type}: {str(e)}")
                            continue
                        
                        # Convert to base64 for storage
                        image_b64 = base64.b64encode(image_bytes).decode('utf-8')
                        
                        # Check connection before each insert
                        if not conn.is_connected():
                            st.warning("⚠️ Reconnecting to database...")
                            conn.reconnect(attempts=2, delay=1)
                        
                        # Insert into database
                        cursor.execute("""
                            INSERT INTO report_images 
                            (report_id, image_type, image_data, image_format) 
                            VALUES (%s, %s, %s, %s)
                        """, (
                            report_id, 
                            image_type, 
                            image_b64, 
                            'PNG'  # or 'JPEG' based on original format
                        ))
                        
                        images_saved += 1
                        
                        
                    except mysql.connector.Error as db_error:
                        st.error(f"❌ Database error saving {image_type}: {db_error}")
                        continue
                    except Exception as e:
                        st.error(f"❌ Error saving {image_type}: {str(e)}")
                        continue
            
            conn.commit()
            return images_saved > 0
            
        except Exception as e:
            st.error(f"❌ General error in image saving: {str(e)}")
            if conn:
                conn.rollback()
            return False
            
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    def _generate_assessments(self, report_data):
        """Generate automatic assessments and recommendations matching the exact format"""
        # Ensure all values are float to avoid decimal/float mixing issues
        def safe_float(value):
            if value is None:
                return 0.0
            try:
                if hasattr(value, 'quantize'):
                    return float(value)
                return float(value)
            except (ValueError, TypeError):
                return 0.0
        
        body_fat = safe_float(report_data['body_fat_percentage'])
        muscle_mass = safe_float(report_data['muscle_mass_almi'])
        bone_density = safe_float(report_data['bone_density_t_score'])
        age = safe_float(report_data['age'])
        gender = report_data['gender']
        visceral_fat = safe_float(report_data['visceral_fat_area'])
        ag_ratio = safe_float(report_data['ag_ratio'])
        
        # Body Zone Assessment
        if body_fat > (28 if gender == 'M' else 35) and muscle_mass > 8:
            body_zone = "POWER RESERVE ZONE"
            zone_description = "You've built good muscle but have higher-than-ideal fat levels - an opportunity to fine-tune composition."
        elif body_fat <= (20 if gender == 'M' else 28) and muscle_mass > 9:
            body_zone = "OPTIMAL ZONE"
            zone_description = "You have an excellent balance of muscle mass and body fat - focus on maintaining this healthy composition."
        elif muscle_mass < 8:
            body_zone = "DEVELOPMENT ZONE"
            zone_description = "You have an opportunity to build muscle mass while optimizing body fat levels through structured training."
        else:
            body_zone = "BALANCED ZONE"
            zone_description = "You have a solid foundation with opportunities to optimize your body composition for better health and performance."
        
        # Muscle Assessment
        if muscle_mass >= 7:
            muscle_assessment_title = "ADEQUATELY MUSCLED"
            muscle_assessment_description = f"ALMI: {muscle_mass} kg/m² (Your ALMI is above 7 - an indicator of adequate skeletal muscle health and physical resilience.)"
            muscle_mass_status = "In Range"
            muscle_mass_color = "#4CAF50"  # Green
        else:
            muscle_assessment_title = "UNDER MUSCLED"
            muscle_assessment_description = f"ALMI: {muscle_mass} kg/m² (Your ALMI is below 7 - indicating an opportunity to build muscle mass for better health and performance.)"
            muscle_mass_status = "Needs Attention"
            muscle_mass_color = "#FF6B3D"  # Red
        
        # Fat Assessment
        body_fat_range = "11.2% - 30.2%" if gender == 'M' else "20.0% - 35.0%"
        if body_fat > (25 if gender == 'M' else 32):
            fat_assessment_title = f"OVER NOURISHED (Body Fat: {body_fat}%)"
            fat_assessment_description = f"For a {age}-year-old {gender.lower()}, your body fat is above the range of {body_fat_range}. This can increase metabolic stress and impact energy, hormones, and recovery. Gradual fat loss may help improve overall health and performance."
            body_fat_status = "Needs Attention"
            body_fat_color = "#FF6B3D"  # Red
        else:
            fat_assessment_title = f"HEALTHY BODY FAT (Body Fat: {body_fat}%)"
            fat_assessment_description = f"For a {age}-year-old {gender.lower()}, your body fat is within the healthy range of {body_fat_range}. Maintain this level through balanced nutrition and regular exercise."
            body_fat_status = "In Range"
            body_fat_color = "#4CAF50"  # Green
        
        # Bone Density Status with detailed color coding
        if bone_density >= -1.0:
            bone_density_status = "In Range"
            bone_density_color = "#4CAF50"  # Green
        elif bone_density >= -2.0:
            bone_density_status = "Suboptimal"
            bone_density_color = "#FFA500"  # Orange/Yellow
        else:
            bone_density_status = "Needs Attention"
            bone_density_color = "#FF6B3D"  # Red
        
        # Bone Health Assessment
        if bone_density >= -1.0:
            bone_health_box_class = "box-green"
            bone_health_box_color = "#4CAF50"
            bone_health_title = "✓ YOUR BONES ARE STRONG"
            bone_health_description = "Your bones are well-mineralised and structurally solid - above the threshold for concern."
        elif bone_density >= -2.5:
            bone_health_box_class = "box-yellow"
            bone_health_box_color = "#FFA500"
            bone_health_title = "⚠️ YOUR BONES ARE WEAKENING"
            bone_health_description = "Your bone density indicates osteopenia. This is an early warning sign that your bones are starting to weaken."
        else:
            bone_health_box_class = "box-red"
            bone_health_box_color = "#FF6B3D"
            bone_health_title = "⚠️ YOUR BONES ARE FRAGILE"
            bone_health_description = "Your bone density indicates osteoporosis. Your bones are fragile and more prone to fractures."
        
        # Fat Distribution Assessment
        if body_fat > (25 if gender == 'M' else 32):
            body_fat_box_class = "box-red"
            body_fat_title = "⚠️ YOUR BODY FAT PERCENTAGE IS UNHEALTHY"
            body_fat_description = "Your body fat percentage is above the healthy reference range. While fat is essential for function, excess can increase the risk of insulin resistance, fatigue, and systemic inflammation. Fat loss through strength and endurance training is recommended."
        else:
            body_fat_box_class = "box-green"
            body_fat_title = "✓ YOUR BODY FAT PERCENTAGE IS HEALTHY"
            body_fat_description = "Your body fat percentage is within the healthy reference range. Maintain this level through balanced nutrition and regular exercise."
        
        # Visceral Fat Assessment
        if visceral_fat > 100:
            visceral_fat_box_class = "box-red"
            visceral_fat_title = "⚠️ YOUR VISCERAL FAT AREA IS HIGH"
            visceral_fat_description = "Your visceral fat area exceeds the healthy threshold. Visceral fat is more hormonally active and linked to insulin resistance, inflammation, and cardiovascular risk."
        else:
            visceral_fat_box_class = "box-green"
            visceral_fat_title = "✓ YOUR VISCERAL FAT AREA IS HEALTHY"
            visceral_fat_description = "Your visceral fat area is within the healthy range. Continue maintaining a healthy lifestyle to keep visceral fat at optimal levels."
        
        # A/G Ratio Assessment
        if ag_ratio > 1.0:
            ag_ratio_box_class = "box-yellow"
            ag_ratio_title = "📊 YOUR A/G RATIO IS SUBOPTIMAL"
            ag_ratio_description = f"Your A/G ratio is {ag_ratio}. Your A/G ratio is above 1.0, indicating a higher proportion of upper body fat (Android pattern). This may be associated with increased cardiovascular risk and insulin resistance."
            ag_ratio_color = "#FFA500"  # Orange/Yellow
        else:
            ag_ratio_box_class = "box-green"
            ag_ratio_title = "✓ YOUR A/G RATIO IS OPTIMAL"
            ag_ratio_description = f"Your A/G ratio is {ag_ratio}. Your A/G ratio is within the optimal range, indicating a healthy fat distribution pattern."
            ag_ratio_color = "#4CAF50"  # Green
        
        # Asymmetry Assessment
        arms_asymmetry = abs(safe_float(report_data.get('arms_asymmetry', 0)))
        legs_asymmetry = abs(safe_float(report_data.get('legs_asymmetry', 0)))
        
        if arms_asymmetry < 5 and legs_asymmetry < 5:
            asymmetry_box_class = "box-green"
            asymmetry_box_color = "#4CAF50"
            asymmetry_title = "✓ YOU HAVE NO ASYMMETRY"
            asymmetry_description = "Your muscle distribution is symmetrical, which supports efficient movement and reduces injury risk. This is the ideal zone for long-term performance and joint health."
        elif arms_asymmetry < 10 and legs_asymmetry < 10:
            asymmetry_box_class = "box-yellow"
            asymmetry_box_color = "#FFA500"
            asymmetry_title = "⚠️ MINOR ASYMMETRY DETECTED"
            asymmetry_description = "You have minor asymmetry in muscle distribution. Consider incorporating unilateral exercises to address imbalances and improve movement efficiency."
        else:
            asymmetry_box_class = "box-red"
            asymmetry_box_color = "#FF6B3D"
            asymmetry_title = "⚠️ SIGNIFICANT ASYMMETRY DETECTED"
            asymmetry_description = "You have significant asymmetry in muscle distribution. This may increase injury risk and affect movement efficiency. Focus on unilateral training and consult with a physical therapist if needed."
        
        # Risk Profile Assessment
        risk_factors = 0
        if body_fat > (25 if gender == 'M' else 32):
            risk_factors += 1
        if visceral_fat > 100:
            risk_factors += 1
        if bone_density < -1.0:
            risk_factors += 1
        if muscle_mass < 7:
            risk_factors += 1
        
        if risk_factors >= 3:
            risk_profile_color = "#FF6B3D"
            risk_profile_title = "⚠️ RISK PROFILE IS HIGH"
            unhealthy_fat_title = "⚠️ UNHEALTHY FAT"
            unhealthy_fat_level = "HIGH"
            unhealthy_fat_color = "#FF6B3D"  # Red
        elif risk_factors >= 2:
            risk_profile_color = "#FFA500"
            risk_profile_title = "⚠️ RISK PROFILE IS MODERATE"
            unhealthy_fat_title = "⚠️ UNHEALTHY FAT"
            unhealthy_fat_level = "MODERATE"
            unhealthy_fat_color = "#FFA500"  # Orange/Yellow
        else:
            risk_profile_color = "#4CAF50"
            risk_profile_title = "✓ RISK PROFILE IS LOW"
            unhealthy_fat_title = "✓ HEALTHY FAT"
            unhealthy_fat_level = "LOW"
            unhealthy_fat_color = "#4CAF50"  # Green
        
        # Fracture Risk Assessment
        if bone_density < -2.5:
            fracture_risk = "HIGH"
            fracture_risk_color = "#FF6B3D"  # Red
        elif bone_density < -1.0:
            fracture_risk = "MODERATE"
            fracture_risk_color = "#FFA500"  # Orange/Yellow
        else:
            fracture_risk = "LOW"
            fracture_risk_color = "#4CAF50"  # Green
        
        # Muscle Loss Risk Assessment
        if muscle_mass < 7:
            muscle_loss_risk = "HIGH"
            muscle_loss_risk_color = "#FF6B3D"  # Red
        elif muscle_mass < 8:
            muscle_loss_risk = "MODERATE"
            muscle_loss_risk_color = "#FFA500"  # Orange/Yellow
        else:
            muscle_loss_risk = "LOW"
            muscle_loss_risk_color = "#4CAF50"  # Green

        return {
            'body_zone': body_zone,
            'zone_description': zone_description,
            'muscle_assessment_title': muscle_assessment_title,
            'muscle_assessment_description': muscle_assessment_description,
            'fat_assessment_title': fat_assessment_title,
            'fat_assessment_description': fat_assessment_description,
            
            # Status with colors for page 2 metrics
            'body_fat_status': body_fat_status,
            'body_fat_color': body_fat_color,
            'muscle_mass_status': muscle_mass_status,
            'muscle_mass_color': muscle_mass_color,
            'bone_density_status': bone_density_status,
            'bone_density_color': bone_density_color,
            
            # Box assessments with colors
            'bone_health_box_class': bone_health_box_class,
            'bone_health_box_color': bone_health_box_color,
            'bone_health_title': bone_health_title,
            'bone_health_description': bone_health_description,
            
            'body_fat_box_class': body_fat_box_class,
            'body_fat_title': body_fat_title,
            'body_fat_description': body_fat_description,
            
            'visceral_fat_box_class': visceral_fat_box_class,
            'visceral_fat_title': visceral_fat_title,
            'visceral_fat_description': visceral_fat_description,
            
            'ag_ratio_box_class': ag_ratio_box_class,
            'ag_ratio_title': ag_ratio_title,
            'ag_ratio_description': ag_ratio_description,
            'ag_ratio_color': ag_ratio_color,
            
            'asymmetry_box_class': asymmetry_box_class,
            'asymmetry_box_color': asymmetry_box_color,
            'asymmetry_title': asymmetry_title,
            'asymmetry_description': asymmetry_description,
            
            # Risk profile with colors
            'risk_profile_color': risk_profile_color,
            'risk_profile_title': risk_profile_title,
            
            # Page 6 risk boxes with colors
            'unhealthy_fat_title': unhealthy_fat_title,
            'unhealthy_fat_level': unhealthy_fat_level,
            'unhealthy_fat_color': unhealthy_fat_color,
            
            'fracture_risk': fracture_risk,
            'fracture_risk_color': fracture_risk_color,
            
            'muscle_loss_risk': muscle_loss_risk,
            'muscle_loss_risk_color': muscle_loss_risk_color
        }

    def _generate_recommendations(self, report_data):
        """Generate automatic nutrition and training recommendations matching the exact format"""
        # Ensure all values are float to avoid decimal/float mixing issues
        def safe_float(value):
            if value is None:
                return 0.0
            try:
                if hasattr(value, 'quantize'):
                    return float(value)
                return float(value)
            except (ValueError, TypeError):
                return 0.0
        
        body_fat = safe_float(report_data['body_fat_percentage'])
        muscle_mass = safe_float(report_data['muscle_mass_almi'])
        bone_density = safe_float(report_data['bone_density_t_score'])
        visceral_fat = safe_float(report_data['visceral_fat_area'])
        total_mass = safe_float(report_data['total_mass'])
        gender = report_data['gender']
        
        nutrition_recommendations = []
        training_recommendations = []
        
        # Nutrition recommendations
        if body_fat > (28 if gender == 'M' else 35):
            nutrition_recommendations.append("Calorie Restriction - You are consuming more calories than your body needs, leading to excess fat storage. Lower your Carbohydrate & Processed food intake.")
        elif body_fat > (25 if gender == 'M' else 32):
            nutrition_recommendations.append("Moderate Calorie Restriction - Focus on whole foods and reduce processed carbohydrates to optimize body composition.")
        else:
            nutrition_recommendations.append("Maintenance Calories - Your body fat is within a healthy range. Focus on nutrient-dense foods and balanced macronutrients.")
        
        # Protein recommendations
        protein_multiplier = 1.6 if muscle_mass < 8.5 else (1.4 if muscle_mass > 11 else 1.5)
        protein_need = round(total_mass * protein_multiplier, 1)
        nutrition_recommendations.append(f"Protein Intake - Consume {protein_need}g of protein daily ({protein_multiplier}g per kg) to support muscle maintenance and metabolism.")
        
        # Visceral fat specific
        if visceral_fat > 100:
            nutrition_recommendations.append("Reduce Saturated Fat - Limit intake of ghee, butter, meats, coconut oil, and fried foods to manage visceral fat accumulation.")
        
        # Training recommendations
        if body_fat > (25 if gender == 'M' else 32):
            cardio_minutes = "200-250" if body_fat > (30 if gender == 'M' else 35) else "150-180"
            training_recommendations.append(f"Zone 2 Cardio - Include {cardio_minutes} minutes weekly of moderate-intensity aerobic exercise at 70-75% of maximum heart rate for optimal fat loss.")
        
        # Strength training
        if muscle_mass < 8.5:
            training_recommendations.append("Strength Training Priority - Focus on compound exercises 3-4 times weekly with progressive overload to build lean muscle mass.")
        elif muscle_mass > 11:
            training_recommendations.append("Maintenance Strength - Continue resistance training 2-3 times weekly to maintain your excellent muscle mass.")
        else:
            training_recommendations.append("Progressive Strength Training - Include resistance training 3 times weekly with gradual progression for optimal muscle maintenance.")
        
        # Bone health
        if bone_density < -1.0:
            training_recommendations.append("Weight-Bearing Exercise - Include impact exercises and resistance training to support bone mineral density.")
        
        return {
            'nutrition_recommendations': nutrition_recommendations,
            'training_recommendations': training_recommendations
        }

    def _calculate_regional_totals(self, report_data):
        """Calculate regional totals and percentages for the asymmetry page matching exact format"""
        # Ensure all values are float to avoid decimal/float mixing issues
        def safe_float(value):
            if value is None:
                return 0.0
            try:
                if hasattr(value, 'quantize'):
                    return float(value)
                return float(value)
            except (ValueError, TypeError):
                return 0.0
        
        # Calculate arm totals
        right_arm_total = safe_float(report_data.get('right_arm_fat', 0)) + safe_float(report_data.get('right_arm_lean', 0)) + safe_float(report_data.get('right_arm_bmc', 0))
        left_arm_total = safe_float(report_data.get('left_arm_fat', 0)) + safe_float(report_data.get('left_arm_lean', 0)) + safe_float(report_data.get('left_arm_bmc', 0))
        
        # Calculate leg totals
        right_leg_total = safe_float(report_data.get('right_leg_fat', 0)) + safe_float(report_data.get('right_leg_lean', 0)) + safe_float(report_data.get('right_leg_bmc', 0))
        left_leg_total = safe_float(report_data.get('left_leg_fat', 0)) + safe_float(report_data.get('left_leg_lean', 0)) + safe_float(report_data.get('left_leg_bmc', 0))
        
        # Calculate trunk total
        trunk_total = safe_float(report_data.get('trunk_fat', 0)) + safe_float(report_data.get('trunk_lean', 0)) + safe_float(report_data.get('trunk_bmc', 0))
        
        # Calculate percentages for trunk composition
        trunk_fat_percent = round((safe_float(report_data.get('trunk_fat', 0)) / trunk_total) * 100) if trunk_total > 0 else 0
        trunk_lean_percent = round((safe_float(report_data.get('trunk_lean', 0)) / trunk_total) * 100) if trunk_total > 0 else 0
        trunk_bone_percent = round((safe_float(report_data.get('trunk_bmc', 0)) / trunk_total) * 100) if trunk_total > 0 else 0
        
        # Calculate percentages for right arm composition
        right_arm_fat_percent = round((safe_float(report_data.get('right_arm_fat', 0)) / right_arm_total) * 100) if right_arm_total > 0 else 0
        right_arm_muscle_percent = round((safe_float(report_data.get('right_arm_lean', 0)) / right_arm_total) * 100) if right_arm_total > 0 else 0
        right_arm_bone_percent = round((safe_float(report_data.get('right_arm_bmc', 0)) / right_arm_total) * 100) if right_arm_total > 0 else 0
        
        # Calculate percentages for left arm composition
        left_arm_fat_percent = round((safe_float(report_data.get('left_arm_fat', 0)) / left_arm_total) * 100) if left_arm_total > 0 else 0
        left_arm_muscle_percent = round((safe_float(report_data.get('left_arm_lean', 0)) / left_arm_total) * 100) if left_arm_total > 0 else 0
        left_arm_bone_percent = round((safe_float(report_data.get('left_arm_bmc', 0)) / left_arm_total) * 100) if left_arm_total > 0 else 0
        
        # Calculate percentages for right leg composition
        right_leg_fat_percent = round((safe_float(report_data.get('right_leg_fat', 0)) / right_leg_total) * 100) if right_leg_total > 0 else 0
        right_leg_muscle_percent = round((safe_float(report_data.get('right_leg_lean', 0)) / right_leg_total) * 100) if right_leg_total > 0 else 0
        right_leg_bone_percent = round((safe_float(report_data.get('right_leg_bmc', 0)) / right_leg_total) * 100) if right_leg_total > 0 else 0
        
        # Calculate percentages for left leg composition
        left_leg_fat_percent = round((safe_float(report_data.get('left_leg_fat', 0)) / left_leg_total) * 100) if left_leg_total > 0 else 0
        left_leg_muscle_percent = round((safe_float(report_data.get('left_leg_lean', 0)) / left_leg_total) * 100) if left_leg_total > 0 else 0
        left_leg_bone_percent = round((safe_float(report_data.get('left_leg_bmc', 0)) / left_leg_total) * 100) if left_leg_total > 0 else 0
        
        # Calculate asymmetry percentages
        arms_asymmetry = round(((right_arm_total - left_arm_total) / ((right_arm_total + left_arm_total) / 2)) * 100, 2) if (right_arm_total + left_arm_total) > 0 else 0
        legs_asymmetry = round(((right_leg_total - left_leg_total) / ((right_leg_total + left_leg_total) / 2)) * 100, 2) if (right_leg_total + left_leg_total) > 0 else 0
        
        return {
            'right_arm_total': round(right_arm_total, 2),
            'left_arm_total': round(left_arm_total, 2),
            'right_leg_total': round(right_leg_total, 2),
            'left_leg_total': round(left_leg_total, 2),
            'trunk_total': round(trunk_total, 2),
            'trunk_fat_percent': trunk_fat_percent,
            'trunk_lean_percent': trunk_lean_percent,
            'trunk_muscle_percent': trunk_lean_percent,  # Add alias for template compatibility
            'trunk_bone_percent': trunk_bone_percent,
            'right_arm_fat_percent': right_arm_fat_percent,
            'right_arm_muscle_percent': right_arm_muscle_percent,
            'right_arm_bone_percent': right_arm_bone_percent,
            'left_arm_fat_percent': left_arm_fat_percent,
            'left_arm_muscle_percent': left_arm_muscle_percent,
            'left_arm_bone_percent': left_arm_bone_percent,
            'right_leg_fat_percent': right_leg_fat_percent,
            'right_leg_muscle_percent': right_leg_muscle_percent,
            'right_leg_bone_percent': right_leg_bone_percent,
            'left_leg_fat_percent': left_leg_fat_percent,
            'left_leg_muscle_percent': left_leg_muscle_percent,
            'left_leg_bone_percent': left_leg_bone_percent,
            'arms_asymmetry': arms_asymmetry,
            'legs_asymmetry': legs_asymmetry,
            'right_arm_fat_g': int(safe_float(report_data.get('right_arm_fat', 0)) * 1000),
            'right_arm_lean_g': int(safe_float(report_data.get('right_arm_lean', 0)) * 1000),
            'right_arm_bmc_g': int(safe_float(report_data.get('right_arm_bmc', 0)) * 1000),
            'left_arm_fat_g': int(safe_float(report_data.get('left_arm_fat', 0)) * 1000),
            'left_arm_lean_g': int(safe_float(report_data.get('left_arm_lean', 0)) * 1000),
            'left_arm_bmc_g': int(safe_float(report_data.get('left_arm_bmc', 0)) * 1000),
            'right_leg_fat_g': int(safe_float(report_data.get('right_leg_fat', 0)) * 1000),
            'right_leg_lean_g': int(safe_float(report_data.get('right_leg_lean', 0)) * 1000),
            'right_leg_bmc_g': int(safe_float(report_data.get('right_leg_bmc', 0)) * 1000),
            'left_leg_fat_g': int(safe_float(report_data.get('left_leg_fat', 0)) * 1000),
            'left_leg_lean_g': int(safe_float(report_data.get('left_leg_lean', 0)) * 1000),
            'left_leg_bmc_g': int(safe_float(report_data.get('left_leg_bmc', 0)) * 1000),
        }

    async def _generate_pdf_async_optimized(self, html_content, page_size='A4'):
        """Optimized async PDF generation"""
        browser = await self._get_browser()
        page = await browser.new_page()
        
        try:
            await page.set_content(html_content, wait_until='networkidle')
            
            # Simplified PDF options
            pdf_bytes = await page.pdf(
                format=page_size, 
                print_background=True,
                margin={'top': '0.5in', 'right': '0.5in', 'bottom': '0.5in', 'left': '0.5in'}
            )
            return pdf_bytes
            
        finally:
            await page.close()

    def _prerender_template(self, report_data):
        """Pre-render template with reliable image URLs - FIXED VERSION"""
        # Get uploaded images from database
        stored_images = self._get_report_images_for_pdf(report_data['report_id'])
        
        # Convert ALL images to base64 data URLs for maximum reliability
        image_urls = {}
        
        # Process uploaded medical images - use base64 for reliability
        medical_image_types = ['ap_spine', 'right_femur', 'left_femur', 'body_outline', 'fat_distribution']
        
        for img_type in medical_image_types:
            if stored_images.get(img_type):
                try:
                    image_bytes = stored_images[img_type].getvalue()
                    base64_data = base64.b64encode(image_bytes).decode('utf-8')
                    
                    # Detect image format
                    if image_bytes.startswith(b'\x89PNG'):
                        mime_type = 'image/png'
                    elif image_bytes.startswith(b'\xff\xd8'):
                        mime_type = 'image/jpeg'
                    else:
                        mime_type = 'image/jpeg'  # default
                    
                    image_urls[img_type] = f"data:{mime_type};base64,{base64_data}"
                    
                except Exception as e:
                    # Use static placeholder as fallback
                    image_urls[img_type] = self._get_base64_placeholder(img_type)
            else:
                # Use static placeholder image
                image_urls[img_type] = self._get_base64_placeholder(img_type)
        
        # Process static images (logo, icons, etc.) - use base64 for consistency
        static_images_mapping = {
            'vital_insights_logo_url': 'vital_insights_logo',
            'fingerprint_icon_url': 'fingerprint_icon',
            'body_outline_image_url': 'body_outline',
            'ap_spine_placeholder_url': 'ap_spine_placeholder',
            'left_femur_url': 'left_femur',
            'right_femur_url': 'right_femur',
            'fat_distribution_placeholder_url': 'fat_distribution_placeholder'
        }
        
        for url_key, image_name in static_images_mapping.items():
            try:
                image_urls[url_key] = self._get_static_image_as_base64(image_name)
            except Exception as e:
                st.error(f"❌ Error loading static image {image_name}: {str(e)}")
                image_urls[url_key] = self._get_base64_placeholder(image_name)
        
        # Generate assessments and recommendations
        assessments = self._generate_assessments(report_data)
        recommendations = self._generate_recommendations(report_data)
        regional_data = self._calculate_regional_totals(report_data)
        
        # Prepare template data with ALL image URLs
        template_data = {
            'patient_name': report_data.get('patient_name', 'BRI.K'),
            'patient_id': report_data.get('patient_id', '000480'),
            'report_id': report_data.get('report_id', '000653'),
            'report_date': report_data.get('report_date', '17 SEP 2025'),
            'age': report_data.get('age', 36),
            'gender': report_data.get('gender', 'M'),
            'height': report_data.get('height', 171),
            'total_mass': report_data.get('total_mass', 104.6),
            'fat_mass': report_data.get('fat_mass', 39.79),
            'lean_mass': report_data.get('lean_mass', 61.84),
            'bone_mass': report_data.get('bone_mass', 2.94),
            'body_fat_percentage': report_data.get('body_fat_percentage', 38.0),
            'muscle_mass_almi': report_data.get('muscle_mass_almi', 10.23),
            'bone_density_t_score': report_data.get('bone_density_t_score', -0.6),
            'visceral_fat_area': report_data.get('visceral_fat_area', 170.0),
            'ag_ratio': report_data.get('ag_ratio', 1.23),
            'ffmi': report_data.get('ffmi', 20.67),
            'fracture_risk': report_data.get('fracture_risk', 'LOW'),
            'muscle_loss_risk': report_data.get('muscle_loss_risk', 'LOW'),
            'z_score': report_data.get('z_score', -0.6),
            
            # Image URLs - ALL as base64 data URLs
            'vital_insights_logo_url': image_urls['vital_insights_logo_url'],
            'fingerprint_icon_url': image_urls['fingerprint_icon_url'],
            'body_outline_image_url': image_urls['body_outline'],
            'ap_spine_image_url': image_urls['ap_spine'],
            'right_femur_image_url': image_urls['right_femur'],
            'left_femur_image_url': image_urls['left_femur'],
            'fat_distribution_image_url': image_urls['fat_distribution'],
            
            # Static placeholder URLs (for template compatibility)
            'body_outline_image_url': image_urls['body_outline_image_url'],
            'ap_spine_placeholder_url': image_urls['ap_spine_placeholder_url'],
            'left_femur_url': image_urls['left_femur_url'],
            'right_femur_url': image_urls['right_femur_url'],
            'fat_distribution_placeholder_url': image_urls['fat_distribution_placeholder_url'],
            
            # Measurements data
            'ap_spine_measurements': report_data.get('ap_spine_measurements', []),
            'right_femur_measurements': report_data.get('right_femur_measurements', []),
            'left_femur_measurements': report_data.get('left_femur_measurements', []),
            
            **assessments,
            **recommendations,
            **regional_data
        }
        
        # Debug: Show which images are being used
       
        # Render HTML template
        html_content = self.html_template.render(**template_data)
        return html_content

    def _get_static_image_as_base64(self, image_name):
        """Convert static image to base64 data URL"""
        try:
            image_path = self.static_images.get(image_name)
            if image_path and image_path.exists():
                with open(image_path, 'rb') as f:
                    image_data = f.read()
                    base64_data = base64.b64encode(image_data).decode('utf-8')
                    
                    if image_path.suffix.lower() == '.png':
                        mime_type = 'image/png'
                    else:
                        mime_type = 'image/jpeg'
                    
                    return f"data:{mime_type};base64,{base64_data}"
            else:
                return self._get_base64_placeholder(image_name)
        except Exception as e:
            st.error(f"Error loading static image {image_name}: {str(e)}")
            return self._get_base64_placeholder(image_name)

    def _get_base64_placeholder(self, image_type):
        """Generate a base64 placeholder image"""
        try:
            # Create a simple placeholder image
            from PIL import Image, ImageDraw
            import io
            
            # Size based on image type
            sizes = {
                'ap_spine': (150, 200),
                'right_femur': (120, 180),
                'left_femur': (120, 180),
                'body_outline': (130, 280),
                'fat_distribution': (100, 150),
                'vital_insights_logo': (180, 60),
                'fingerprint_icon': (60, 60)
            }
            
            width, height = sizes.get(image_type, (100, 100))
            
            # Create image
            img = Image.new('RGB', (width, height), color=(240, 240, 240))
            draw = ImageDraw.Draw(img)
            
            # Draw border
            draw.rectangle([0, 0, width-1, height-1], outline=(200, 200, 200), width=1)
            
            # Draw text
            try:
                # Try to use a font
                font_size = max(12, min(width // 10, 20))
                from PIL import ImageFont
                font = ImageFont.load_default()
                text = image_type.replace('_', ' ').title()
                
                # Calculate text position
                bbox = draw.textbbox((0, 0), text, font=font)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                x = (width - text_width) // 2
                y = (height - text_height) // 2
                
                draw.text((x, y), text, fill=(150, 150, 150), font=font)
            except:
                # Fallback without font
                text = image_type[:15]
                x = width // 4
                y = height // 2 - 10
                draw.text((x, y), text, fill=(150, 150, 150))
            
            # Convert to base64
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            base64_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
            
            return f"data:image/png;base64,{base64_data}"
            
        except Exception as e:
            # Ultimate fallback - transparent 1x1 pixel
            return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
        
    def generate_pdf_with_timeout(self, report_data, page_size='A4', timeout=30):
        """Generate PDF with timeout protection"""
        try:
            # Convert all decimal values to float
            def convert_to_float(value):
                if value is None:
                    return 0.0
                try:
                    if hasattr(value, 'quantize'):
                        return float(value)
                    return float(value)
                except (ValueError, TypeError):
                    return 0.0
            
            # Convert all numeric values in report_data to float
            converted_report_data = {}
            for key, value in report_data.items():
                if isinstance(value, (int, float, str)) and str(value).replace('.', '').replace('-', '').isdigit():
                    converted_report_data[key] = convert_to_float(value)
                else:
                    converted_report_data[key] = value
            
            report_data = converted_report_data
            
            # Pre-render template outside async context
            html_content = self._prerender_template(report_data)
            
            # Run async function with timeout
            def _run_with_timeout(coro, timeout_sec):
                return asyncio.run(asyncio.wait_for(coro, timeout=timeout_sec))

            try:
                return _run_with_timeout(self._generate_pdf_async_optimized(html_content, page_size), timeout)
            except NotImplementedError as ne:
                # On some Windows hosts the default event loop/policy doesn't support subprocesses
                # which Playwright needs to spawn the browser. Try switching to the Proactor policy
                # and retry once. This mirrors the recommended fix for Windows asyncio subprocess support.
                if sys.platform.startswith("win") or os.name == 'nt':
                    st.warning("Detected event loop without subprocess support; switching to WindowsProactorEventLoopPolicy and retrying...")
                    try:
                        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
                    except Exception:
                        st.text(traceback.format_exc())
                    try:
                        return _run_with_timeout(self._generate_pdf_async_optimized(html_content, page_size), timeout)
                    except Exception:
                        st.text(traceback.format_exc())
                        return None
                else:
                    # Re-raise for non-Windows platforms
                    raise
            
        except asyncio.TimeoutError:
            st.error("PDF generation timed out. Please try again.")
            return None
        except Exception as e:
            # Show full traceback to the UI to help debugging
            tb = traceback.format_exc()
            st.error(f"❌ Error in PDF generation: {str(e)}")
            st.text(tb)

            # If this is caused by a running event loop (common in some hosting environments),
            # try using an alternate approach for running async code
            if 'asyncio.run() cannot be called from a running event loop' in str(e):
                try:
                    # Create a new event loop and run the coroutine there
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(asyncio.wait_for(
                        self._generate_pdf_async_optimized(html_content, page_size),
                        timeout=timeout
                    ))
                    loop.close()
                    return result
                except Exception:
                    st.text(traceback.format_exc())

            return None
    def generate_pdf(self, report_data, page_size='A4'):
        return self.generate_pdf_with_timeout(report_data, page_size)

    def save_to_supabase_storage(self, pdf_bytes, filename, report_id, file_format):
        """Save PDF to Supabase storage - FIXED VERSION"""
        try:
            # Generate unique filename to avoid conflicts
            unique_filename = f"{uuid.uuid4()}_{filename}"
            
            # Upload file
            result = self.supabase_storage.supabase.storage.from_(self.supabase_storage.bucket_name).upload(
                unique_filename,
                pdf_bytes,
                {"content-type": "application/pdf"}
            )
            
            if result and not hasattr(result, 'error'):
                # Get public URL
                try:
                    file_url = self.supabase_storage.supabase.storage.from_(self.bucket_name).get_public_url(unique_filename)
                except:
                    # If bucket is private, create a signed URL
                    signed_url = self.supabase_storage.supabase.storage.from_(self.bucket_name).create_signed_url(unique_filename, 3600)
                    file_url = signed_url.signed_url if signed_url else f"Private file: {unique_filename}"
                
                file_size_kb = len(pdf_bytes) / 1024
                
                # Store file metadata in database - FIXED: Ensure hospital_id is included
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor()
                    
                    # Get hospital_id from the report
                    cursor.execute("SELECT hospital_id FROM dexa_reports WHERE report_id = %s", (report_id,))
                    report_result = cursor.fetchone()
                    hospital_id = report_result[0] if report_result else st.session_state.user['hospital_id']
                    
                    cursor.execute("""
                    INSERT INTO supabase_files (report_id, hospital_id, filename, unique_filename, file_url, file_size_kb, file_format, uploaded_by)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        report_id, 
                        hospital_id,  # ✅ FIXED: Ensure hospital_id is always provided
                        filename, 
                        unique_filename, 
                        file_url, 
                        file_size_kb, 
                        file_format, 
                        st.session_state.user['user_id']
                    ))
                    conn.commit()
                    cursor.close()
                    conn.close()
                
                return True, file_size_kb, file_url, unique_filename
            
            return False, f"Upload failed: {getattr(result, 'error', 'Unknown error')}", None, None
            
        except Exception as e:
            st.error(f"❌ Error saving to Supabase: {str(e)}")
            return False, str(e), None, None

    def list_stored_reports(self):
        """List all stored reports in Supabase storage"""
        return self.supabase_storage.list_supabase_files()
    
    def get_storage_info(self):
        """Get storage usage information"""
        return self.supabase_storage.get_storage_info()

# =============================================================================
# SUPABASE CLOUD STORAGE MANAGEMENT
# =============================================================================

class SupabaseStorageManager:
    def __init__(self):
        try:
            self.supabase_url = st.secrets["SUPABASE_URL"]
            self.supabase_key = st.secrets.get("SUPABASE_SERVICE_ROLE_KEY", st.secrets["SUPABASE_KEY"])
            self.supabase = create_client(self.supabase_url, self.supabase_key)
            self.bucket_name = "pdf_reports"
            self.setup_supabase_storage()
        except KeyError as e:
            st.error(f"❌ Missing required Supabase configuration: {e}")
            raise
        except Exception as e:
            st.error(f"❌ Failed to initialize Supabase client: {e}")
            raise
    
    def setup_supabase_storage(self):
        """Setup Supabase storage bucket"""
        try:
            # Check if bucket exists, create if not
            buckets = self.supabase.storage.list_buckets()
            bucket_names = [bucket.name for bucket in buckets]
            
            if self.bucket_name not in bucket_names:
                # Create bucket with proper configuration
                result = self.supabase.storage.create_bucket(
                    self.bucket_name,
                    options={
                        "public": False,
                        "allowed_mime_types": ["application/pdf"],
                        "file_size_limit": 10485760,  # 10MB limit
                    }
                )
            else:
                pass
                
        except Exception as e:
            st.error(f"Error setting up Supabase storage: {str(e)}")
    
    def upload_pdf_to_supabase(self, pdf_bytes, filename, report_id, file_format):
        """Upload PDF to Supabase storage"""
        try:
            # Generate unique filename to avoid conflicts
            unique_filename = f"{uuid.uuid4()}_{filename}"
            
            # Upload file
            result = self.supabase_storage.supabase.storage.from_(self.supabase_storage.bucket_name).upload(
                unique_filename,
                pdf_bytes,
                {"content-type": "application/pdf"}
            )
            
            if result and not hasattr(result, 'error'):
                # Get public URL
                try:
                    file_url = self.supabase_storage.supabase.storage.from_(self.supabase_storage.bucket_name).get_public_url(unique_filename)
                except:
                    # If bucket is private, create a signed URL
                    signed_url = self.supabase_storage.supabase.storage.from_(self.supabase_storage.bucket_name).create_signed_url(unique_filename, 3600)
                    file_url = signed_url.signed_url if signed_url else f"Private file: {unique_filename}"
                
                file_size_kb = len(pdf_bytes) / 1024
                
                # Store file metadata in database
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                    INSERT INTO supabase_files (report_id, hospital_id, filename, unique_filename, file_url, file_size_kb, file_format, uploaded_by)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    report_id, 
                    st.session_state.user['hospital_id'],  # ✅ ADD hospital_id
                    filename, 
                    unique_filename, 
                    file_url, 
                    file_size_kb, 
                    file_format, 
                    st.session_state.user['user_id']
                ))
                    conn.commit()
                    cursor.close()
                    conn.close()
                
                return True, file_size_kb, file_url, unique_filename
            
            return False, f"Upload failed: {getattr(result, 'error', 'Unknown error')}", None, None
            
        except Exception as e:
            return False, str(e), None, None
    
    def list_supabase_files(self):
        """List all files in Supabase storage"""
        try:
            conn = get_db_connection()
            if not conn:
                return []
            
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT sf.*, r.report_id, p.first_name, p.last_name,r.hospital_id
                FROM supabase_files sf
                JOIN dexa_reports r ON sf.report_id = r.report_id
                JOIN patients p ON r.patient_id = p.patient_id
                ORDER BY sf.created_at DESC
            """)
            files = cursor.fetchall()
            cursor.close()
            conn.close()
            
            return files
        except Exception as e:
            return []
    
    def delete_supabase_file(self, unique_filename):
        """Delete file from Supabase storage"""
        try:
            result = self.supabase_storage.supabase.storage.from_(self.supabase_storage.bucket_name).remove([unique_filename])
            
            # Also delete from database
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM supabase_files WHERE unique_filename = %s", (unique_filename,))
                conn.commit()
                cursor.close()
                conn.close()
            
            return True
        except Exception as e:
            return False
    
    def get_storage_info(self):
        """Get storage usage information"""
        try:
            files = self.list_supabase_files()
            total_size_mb = sum(file['file_size_kb'] for file in files) / 1024
            return len(files), total_size_mb
        except Exception as e:
            return 0, 0

# =============================================================================
# VALIDATION FUNCTIONS
# =============================================================================

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Validate phone number (10 digits)"""
    pattern = r'^\d{10}$'
    return re.match(pattern, phone) is not None

def validate_password(password):
    """Validate password (6 or more characters)"""
    return len(password) >= 6

# =============================================================================
# AUTHENTICATION & USER MANAGEMENT WITH EMAIL NOTIFICATIONS
# =============================================================================

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def authenticate_user(username, password):
    """Authenticate user credentials"""
    conn = get_db_connection()
    if not conn:
        return None
    
    cursor = conn.cursor(dictionary=True)
    try:
        password_hash = hash_password(password)
        cursor.execute("""
             SELECT u.user_id, u.username, u.user_type, u.full_name, u.hospital_id, 
                   h.hospital_name, h.address, h.phone_number, h.email
            FROM users u 
            LEFT JOIN hospitals h ON u.hospital_id = h.hospital_id
            WHERE u.username = %s AND u.password_hash = %s
        """, (username, password_hash))
        
        user = cursor.fetchone()
        return user
    except Exception as e:
        return None
    finally:
        cursor.close()
        conn.close()

def create_hospital(hospital_data):
    """Create new hospital"""
    conn = get_db_connection()
    if not conn:
        return False
    
    cursor = conn.cursor()
    try:
        hospital_id = f"hosp_{uuid.uuid4().hex[:8]}"
        cursor.execute("""
            INSERT INTO hospitals (hospital_id, hospital_name, hospital_code, address, phone_number, email)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (hospital_id, hospital_data['hospital_name'], hospital_data['hospital_code'], 
              hospital_data['address'], hospital_data['phone_number'], hospital_data['email']))
        
        conn.commit()
        return hospital_id
    except Exception as e:
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

def create_user_with_email_notification(user_data):
    """Create new user and send credentials via email with admin notification - FIXED VERSION"""
    conn = get_db_connection()
    if not conn:
        return False, "Database connection failed"
    
    cursor = conn.cursor(dictionary=True)
    try:
        # Check if username already exists
        cursor.execute("SELECT user_id FROM users WHERE username = %s", (user_data['username'],))
        if cursor.fetchone():
            return False, "Username already exists"
            
        # Generate a secure temporary password
        temp_password = generate_secure_password()
        hashed_password = hash_password(temp_password)
        
        # Generate a unique user_id
        user_id = f"user_{uuid.uuid4().hex[:8]}"
        
        # Insert new user with explicit user_id
        cursor.execute("""
            INSERT INTO users (
                user_id,
                username, 
                password_hash, 
                user_type, 
                full_name, 
                email, 
                mobile_number, 
                hospital_id,
                is_first_login
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, TRUE)
        """, (
            user_id,
            user_data['username'],
            hashed_password,
            user_data.get('user_type', 'user'),
            user_data['full_name'],
            user_data.get('email'),
            user_data.get('mobile_number'),
            user_data['hospital_id']
        ))
        
        conn.commit()
        
        # Get hospital information for email
        hospital_info = get_hospital_info(user_data['hospital_id'])
        
        # Initialize email system
        email_system = EmailNotificationSystem()
        
        # Send email with credentials if email is provided
        email_sent = False
        email_message = ""
        if user_data.get('email'):
            success, message = email_system.send_user_credentials(
                user_data=user_data,
                hospital_info=hospital_info,
                temp_password=temp_password
            )
            if success:
                email_sent = True
                email_message = f"Credentials sent to {user_data['email']}"
            else:
                email_message = f"User created but email failed: {message}"
        else:
            email_message = "User created but no email provided for credentials"
        
        # Send admin notification
        if hospital_info:
            # Get admin users for this hospital
            cursor.execute("""
                SELECT user_id, full_name, email, user_type 
                FROM users 
                WHERE hospital_id = %s AND user_type = 'admin'
            """, (user_data['hospital_id'],))
            admins = cursor.fetchall()
            
            for admin in admins:
                admin_notification_success, admin_message = email_system.send_admin_notification(
                    admin_data=admin,
                    new_user_data=user_data,
                    hospital_info=hospital_info
                )
                if admin_notification_success:
                    email_message += f" | Admin notified: {admin['email']}"
                else:
                    email_message += f" | Admin notification failed: {admin_message}"
        
        return True, f"User created successfully. {email_message}"
        
    except Exception as e:
        conn.rollback()
        return False, f"Error creating user: {str(e)}"
    finally:
        cursor.close()
        conn.close()

def create_user(user_data):
    """Create a new user - FIXED VERSION"""
    conn = get_db_connection()
    if not conn:
        return False
    
    cursor = conn.cursor()
    try:
        # Generate unique user_id
        user_id = f"user_{uuid.uuid4().hex[:8]}"
        
        cursor.execute("""
            INSERT INTO users (
                user_id,
                username, 
                password_hash, 
                user_type, 
                full_name, 
                mobile_number, 
                hospital_id
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            user_id,
            user_data['username'],
            hash_password(user_data['password']),
            user_data['user_type'],
            user_data['full_name'],
            user_data['mobile_number'],
            user_data['hospital_id']
        ))
        
        conn.commit()
        return True
    except Exception as e:
        conn.rollback()
        st.error(f"Error creating user: {str(e)}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_hospital_info(hospital_id):
    """Get hospital information by ID"""
    conn = get_db_connection()
    if not conn:
        return None
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                hospital_id,
                hospital_name,
                address,
                phone_number,
                email
            FROM hospitals 
            WHERE hospital_id = %s
        """, (hospital_id,))
        
        return cursor.fetchone()
    except Exception:
        return None
    finally:
        cursor.close()
        conn.close()

def link_patient_to_user(patient_id, user_id):
    """Link patient to user for access control"""
    conn = get_db_connection()
    if not conn:
        return False
    
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT IGNORE INTO patient_user_mapping (patient_id, user_id)
            VALUES (%s, %s)
        """, (patient_id, user_id))
        
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error linking patient to user: {str(e)}")
        return False
    finally:
        cursor.close()
        conn.close()

@st.cache_data(ttl=300, show_spinner=False)
def get_all_patients_cached():
    """Get all patients for admin management - CACHED"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT patient_id, first_name, last_name, age, gender FROM patients ORDER BY created_at DESC")
        patients = cursor.fetchall()
        return patients
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

@st.cache_data(ttl=300, show_spinner=False)
def get_all_users_cached():
    """Get all users for admin management - CACHED"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT user_id, username, user_type, full_name, email, mobile_number FROM users ORDER BY created_at DESC")
        users = cursor.fetchall()
        return users
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

@st.cache_data(ttl=60, show_spinner=False)
def get_user_reports_optimized(user_id, hospital_id):
    """Get reports accessible to user - FIXED: Only assigned reports"""
    conn = get_db_connection()
    if not conn:
        return []
    
    try:
        # Different query for admin vs regular users
        if st.session_state.user['user_type'] == 'admin':
            # Admin can see all reports from their hospital
            query = """
                SELECT 
                    r.report_id, r.patient_id, r.report_date, r.total_mass, 
                    r.fat_mass, r.lean_mass,r.bone_mass,r.ffmi, r.body_fat_percentage,
                    r.muscle_mass_almi, r.bone_density_t_score, r.visceral_fat_area,
                    p.first_name, p.last_name, p.age, p.gender
                FROM dexa_reports r 
                JOIN patients p ON r.patient_id = p.patient_id
                WHERE r.hospital_id = %s 
                  AND r.is_published = TRUE
                ORDER BY r.created_at DESC
                LIMIT 200
            """
            cursor = conn.cursor(dictionary=True)
            cursor.execute(query, (hospital_id,))
        else:
            # Regular users can ONLY see reports they're explicitly assigned to
            query = """
                SELECT 
                    r.report_id, r.patient_id, r.report_date, r.total_mass, 
                    r.fat_mass, r.lean_mass,r.bone_mass,r.ffmi, r.body_fat_percentage,
                    r.muscle_mass_almi, r.bone_density_t_score, r.visceral_fat_area,
                    p.first_name, p.last_name, p.age, p.gender
                FROM dexa_reports r 
                JOIN patients p ON r.patient_id = p.patient_id
                JOIN patient_user_mapping m ON r.patient_id = m.patient_id
                WHERE r.hospital_id = %s 
                  AND r.is_published = TRUE
                  AND m.user_id = %s  # ← CRITICAL: Only assigned reports
                ORDER BY r.created_at DESC
                LIMIT 200
            """
            cursor = conn.cursor(dictionary=True)
            cursor.execute(query, (hospital_id, user_id))
        
        return cursor.fetchall()
        
    except Exception as e:
        return []
    finally:
        if conn:
            conn.close()
@st.cache_data(ttl=300, show_spinner=False)
def get_hospital_users_cached(hospital_id):
    """Get all users for a specific hospital - CACHED"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT user_id, username, user_type, full_name, email, mobile_number 
            FROM users 
            WHERE hospital_id = %s 
            ORDER BY created_at DESC
        """, (hospital_id,))
        users = cursor.fetchall()
        return users
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

@st.cache_data(ttl=300, show_spinner=False)
def get_hospital_patients_cached(hospital_id):
    """Get all patients for a specific hospital - CACHED"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT patient_id, first_name, last_name, age, gender 
            FROM patients 
            WHERE hospital_id = %s 
            ORDER BY created_at DESC
        """, (hospital_id,))
        patients = cursor.fetchall()
        return patients
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

# =============================================================================
# UPDATED USER REGISTRATION PAGES WITH EMAIL NOTIFICATIONS
# =============================================================================

def show_user_registration_page():
    """Show user registration page (for existing hospitals) with email notifications"""
    st.markdown('<h2 style="text-align: center;">👤 User Registration</h2>', unsafe_allow_html=True)
    
    # Get hospitals for selection
    conn = get_db_connection()
    hospitals = []
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT hospital_id, hospital_name FROM hospitals")
        hospitals = cursor.fetchall()
        cursor.close()
        conn.close()
    
    if not hospitals:
        st.error("No hospitals registered yet. Please register a hospital first.")
        if st.button("← Back to Login"):
            st.session_state.show_register = False
            st.rerun()
        return
    
    hospital_options = {h['hospital_name']: h['hospital_id'] for h in hospitals}
    
    with st.form("user_registration"):
        selected_hospital = st.selectbox("Select Hospital*", list(hospital_options.keys()))
        hospital_id = hospital_options[selected_hospital]
        
        col1, col2 = st.columns(2)
        with col1:
            full_name = st.text_input("Full Name*", placeholder="Enter your full name")
            username = st.text_input("Username*", placeholder="Choose a username")
            email = st.text_input("Email Address*", placeholder="your.email@example.com")
        
        with col2:
            mobile_number = st.text_input("Mobile Number*", placeholder="10-digit mobile number")
            user_type = st.selectbox("User Type*", ["user", "admin"], help="Admins have full system access")
            send_credentials = st.checkbox("Send login credentials via email", value=True, 
                                         help="Uncheck if you don't want to receive email with login details")
        
        # Show email configuration status
        email_system = EmailNotificationSystem()
        if not email_system.sender_email or not email_system.sender_password:
            st.warning("⚠️ Email system not configured. Credentials will not be sent.")
            send_credentials = False
        
        col3, col4 = st.columns(2)
        with col3:
            register_btn = st.form_submit_button("👤 Register User", use_container_width=True)
        with col4:
            if st.form_submit_button("← Back to Login", use_container_width=True):
                st.session_state.show_register = False
                st.rerun()
        
        if register_btn:
            # Validate inputs
            errors = []
            
            if not all([full_name, username, mobile_number, email]):
                errors.append("All fields are required")
            
            if not validate_email(email):
                errors.append("Invalid email format")
            
            if not validate_phone(mobile_number):
                errors.append("Invalid mobile number format (10 digits required)")
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                user_data = {
                    'hospital_id': hospital_id,
                    'username': username,
                    'user_type': user_type,
                    'full_name': full_name,
                    'email': email,
                    'mobile_number': mobile_number
                }
                
                # Create user with email notifications
                success, message = create_user_with_email_notification(user_data)
                
                if success:
                    st.success(f"✅ {message}")
                    
                    # Show temporary password info if email was sent
                    if send_credentials and "sent" in message.lower():
                        st.info("📧 Login credentials have been sent to the user's email address.")
                    elif not send_credentials:
                        st.info("ℹ️ User created without email notification.")
                    
                    # Add a delay before redirecting
                    time.sleep(2)
                    st.session_state.show_register = False
                    st.rerun()
                else:
                    st.error(f"❌ {message}")

def show_admin_user_management(user):
    """Admin user management with enhanced email features"""
    st.markdown('<div class="section-header">👥 User Management</div>', unsafe_allow_html=True)
    
    # Email system status
    email_system = EmailNotificationSystem()
    email_configured = email_system.sender_email and email_system.sender_password
    
    if not email_configured:
        st.warning("""
        ⚠️ Email system not configured. User credentials cannot be sent automatically.
        Please configure SMTP settings in your secrets.toml file to enable email notifications.
        """)
    
    # Create new user form
    with st.form("create_user_form"):
        st.markdown("### Create New User")
        
        col1, col2 = st.columns(2)
        with col1:
            full_name = st.text_input("Full Name*", placeholder="Enter full name")
            username = st.text_input("Username*", placeholder="Choose username")
            email = st.text_input("Email Address*", placeholder="user@example.com")
        
        with col2:
            mobile_number = st.text_input("Mobile Number*", placeholder="10-digit number")
            user_type = st.selectbox("User Type*", ["user", "admin"])
            send_email = st.checkbox("Send credentials via email", value=email_configured, 
                                   disabled=not email_configured,
                                   help="Send login credentials to user's email")
        
        if st.form_submit_button("Create User"):
            if all([full_name, username, mobile_number, email]):
                if not validate_email(email):
                    st.error("Invalid email format")
                elif not validate_phone(mobile_number):
                    st.error("Invalid mobile number format (10 digits required)")
                else:
                    user_data = {
                        'hospital_id': user['hospital_id'],
                        'username': username,
                        'user_type': user_type,
                        'full_name': full_name,
                        'email': email if send_email else None,
                        'mobile_number': mobile_number
                    }
                    
                    success, message = create_user_with_email_notification(user_data)
                    
                    if success:
                        st.success(f"✅ {message}")
                        if send_email:
                            st.info("📧 Login credentials sent to user's email")
                        st.rerun()
                    else:
                        st.error(f"❌ {message}")
            else:
                st.error("Please fill all required fields")
    
    # User list with management options
    st.markdown("### Existing Users")
    users = get_hospital_users_cached(user['hospital_id'])
    
    if users:
        for user_item in users:
            col1, col2, col3 = st.columns([3, 2, 1])
            with col1:
                st.write(f"**{user_item['full_name']}** ({user_item['username']})")
                st.write(f"📧 {user_item.get('email', 'No email')} | 📞 {user_item.get('mobile_number', 'No phone')} | 👤 {user_item['user_type'].title()}")
            
            with col2:
                if user_item['user_id'] != user['user_id']:
                    if st.button("Reset Password", key=f"reset_{user_item['user_id']}"):
                        # Simple password reset with email notification
                        new_password = generate_secure_password()
                        conn = get_db_connection()
                        if conn:
                            cursor = conn.cursor()
                            cursor.execute("UPDATE users SET password_hash = %s WHERE user_id = %s", 
                                         (hash_password(new_password), user_item['user_id']))
                            conn.commit()
                            
                            # Send email with new password if email exists
                            if user_item.get('email') and email_configured:
                                hospital_info = get_hospital_info(user['hospital_id'])
                                if hospital_info:
                                    email_success, email_message = email_system.send_user_credentials(
                                        user_data=user_item,
                                        hospital_info=hospital_info,
                                        temp_password=new_password
                                    )
                                    if email_success:
                                        st.success(f"✅ Password reset and sent to {user_item['email']}")
                                    else:
                                        st.warning(f"Password reset but email failed: {email_message}")
                                else:
                                    st.info(f"Password reset to: {new_password}")
                            else:
                                st.info(f"Password reset to: {new_password}")
                            
                            cursor.close()
                            conn.close()
            
            with col3:
                if user_item['user_id'] != user['user_id']:
                    if st.button("Delete", key=f"delete_{user_item['user_id']}"):
                        conn = get_db_connection()
                        if conn:
                            cursor = conn.cursor()
                            try:
                                cursor.execute("DELETE FROM patient_user_mapping WHERE user_id = %s", (user_item['user_id'],))
                                cursor.execute("DELETE FROM users WHERE user_id = %s", (user_item['user_id'],))
                                conn.commit()
                                st.success("User deleted successfully!")
                                st.rerun()
                            except Exception as e:
                                st.error("Error deleting user")
                            finally:
                                cursor.close()
                                conn.close()
    else:
        st.info("No users found.")

# =============================================================================
# REST OF THE CODE REMAINS THE SAME (VERSION CONTROL, PDF GENERATION, ETC.)
# =============================================================================

# ... [The rest of the code remains exactly the same as in the previous optimized version]
# Only the user registration and user management functions have been updated

# Note: The remaining functions (show_login_page, show_hospital_registration_page, 
# and all other application functions) remain exactly the same as in the previous version
# =============================================================================
# REPORT VERSION CONTROL
# =============================================================================

def get_report_versions(report_id):
    """Get all versions of a report - accessible to both admin and users"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT rv.*, u.full_name as editor_name
            FROM report_versions rv 
            LEFT JOIN users u ON rv.edited_by = u.user_id
            WHERE rv.report_id = %s 
            ORDER BY rv.version_number DESC
        """, (report_id,))
        
        versions = cursor.fetchall()
        return versions
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

def get_accessible_report_versions(user_id, hospital_id, user_type):
    """Get all report versions that a user can access"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        if user_type == 'admin':
            # Admin can see all versions from their hospital
            cursor.execute("""
                SELECT rv.*, r.report_id, p.first_name, p.last_name, u.full_name as editor_name
                FROM report_versions rv
                JOIN dexa_reports r ON rv.report_id = r.report_id
                JOIN patients p ON r.patient_id = p.patient_id
                LEFT JOIN users u ON rv.edited_by = u.user_id
                WHERE r.hospital_id = %s
                ORDER BY rv.created_at DESC
            """, (hospital_id,))
        else:
            # Regular users can see versions of reports they're linked to
            cursor.execute("""
                SELECT rv.*, r.report_id, p.first_name, p.last_name, u.full_name as editor_name
                FROM report_versions rv
                JOIN dexa_reports r ON rv.report_id = r.report_id
                JOIN patients p ON r.patient_id = p.patient_id
                JOIN patient_user_mapping m ON r.patient_id = m.patient_id
                LEFT JOIN users u ON rv.edited_by = u.user_id
                WHERE m.user_id = %s AND r.hospital_id = %s
                ORDER BY rv.created_at DESC
            """, (user_id, hospital_id))
        
        versions = cursor.fetchall()
        return versions
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

def save_report_version(report_id, report_data, edited_by, edit_reason):
    """Save a new version of the report with improved error handling"""
    conn = get_db_connection()
    if not conn:
        st.error("❌ Database connection failed for version control")
        return False
    
    cursor = conn.cursor()
    try:
        # Set transaction timeout
        cursor.execute("SET SESSION innodb_lock_wait_timeout = 30")
        cursor.execute("SET SESSION wait_timeout = 30")
        
        # Get current max version number
        cursor.execute("SELECT MAX(version_number) as max_version FROM report_versions WHERE report_id = %s", (report_id,))
        result = cursor.fetchone()
        next_version = (result[0] or 0) + 1
        
        # Convert date objects and other non-serializable types to strings for JSON
        serializable_data = {}
        for key, value in report_data.items():
            if isinstance(value, (date, datetime)):
                serializable_data[key] = value.isoformat()
            elif hasattr(value, 'isoformat'):  # Handle other date-like objects
                serializable_data[key] = value.isoformat()
            elif hasattr(value, '__dict__'):  # Handle objects
                serializable_data[key] = str(value)
            else:
                serializable_data[key] = value
        
        # Save version with explicit transaction management
        conn.start_transaction()
        cursor.execute("""
            INSERT INTO report_versions (report_id, version_number, report_data, edited_by, edit_reason)
            VALUES (%s, %s, %s, %s, %s)
        """, (report_id, next_version, json.dumps(serializable_data), edited_by, edit_reason))
        
        conn.commit()
        st.success(f"✅ Version {next_version} saved successfully!")
        return True
        
    except mysql.connector.Error as e:
        if e.errno == 1205:  # Lock wait timeout
            st.warning("⚠️ Database is busy. Please try again in a moment.")
            conn.rollback()
            # Retry once
            try:
                time.sleep(2)
                conn.commit()  # Try to clear any locks
                return save_report_version(report_id, report_data, edited_by, edit_reason)
            except:
                return False
        else:
            conn.rollback()
            return False
    except Exception as e:
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

def publish_report_func(report_id):
    """Mark report as published"""
    conn = get_db_connection()
    if not conn:
        return False
    
    cursor = conn.cursor()
    try:
        cursor.execute("""
            UPDATE dexa_reports 
            SET is_published = TRUE, published_at = CURRENT_TIMESTAMP 
            WHERE report_id = %s
        """, (report_id,))
        
        conn.commit()
        return True
    except Exception as e:
        st.error(f"Error publishing report: {str(e)}")
        return False
    finally:
        cursor.close()
        conn.close()

def get_todays_reports():
    """Get reports created today for editing - HOSPITAL SPECIFIC"""
    conn = get_db_connection()
    if not conn:
        return []
    
    hospital_id = st.session_state.user['hospital_id']
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT r.*, p.first_name, p.last_name 
            FROM dexa_reports r 
            JOIN patients p ON r.patient_id = p.patient_id 
            WHERE DATE(r.created_at) = CURDATE() AND r.hospital_id = %s
            ORDER BY r.created_at DESC
        """, (hospital_id,))
        
        reports = cursor.fetchall()
        return reports
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

def get_supabase_files_by_report(report_id):
    """Get all Supabase files for a specific report"""
    conn = get_db_connection()
    if not conn:
        return []
    
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT * FROM supabase_files 
            WHERE report_id = %s 
            ORDER BY created_at DESC
        """, (report_id,))
        
        files = cursor.fetchall()
        return files
    except Exception as e:
        return []
    finally:
        cursor.close()
        conn.close()

# =============================================================================
# UPDATED DATABASE FUNCTIONS
# =============================================================================

def save_report_data(report_data):
    """Save complete report data to database with all new fields including images"""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            st.error("❌ Failed to connect to database")
            return False
            
        cursor = conn.cursor()
        conn.start_transaction()
        # Save patient with hospital association
        cursor.execute("""
            INSERT IGNORE INTO patients (patient_id, hospital_id, first_name, last_name, age, gender)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (report_data['patient_id'], report_data['hospital_id'], report_data['first_name'], 
              report_data['last_name'], report_data['age'], report_data['gender']))
        
        # Save main report with all new fields
        cursor.execute("""
            INSERT INTO dexa_reports (
                report_id, patient_id, hospital_id, report_date, height, total_mass, fat_mass, 
                lean_mass, bone_mass, body_fat_percentage, muscle_mass_almi, 
                bone_density_t_score, z_score, visceral_fat_area, ag_ratio, ffmi,
                fracture_risk, muscle_loss_risk, 
                right_arm_fat, right_arm_lean, right_arm_bmc,
                left_arm_fat, left_arm_lean, left_arm_bmc,
                right_leg_fat, right_leg_lean, right_leg_bmc,
                left_leg_fat, left_leg_lean, left_leg_bmc,
                trunk_fat, trunk_lean, trunk_bmc,
                created_by, is_published
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                     %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            report_data['report_id'], report_data['patient_id'], report_data['hospital_id'],
            report_data['report_date'], report_data['height'], report_data['total_mass'], 
            report_data['fat_mass'], report_data['lean_mass'],
            report_data['bone_mass'], report_data['body_fat_percentage'],
            report_data['muscle_mass_almi'], report_data['bone_density_t_score'],
            report_data['z_score'], report_data['visceral_fat_area'], report_data['ag_ratio'],
            report_data['ffmi'], report_data['fracture_risk'],
            report_data['muscle_loss_risk'],
            report_data.get('right_arm_fat', 0), report_data.get('right_arm_lean', 0), report_data.get('right_arm_bmc', 0),
            report_data.get('left_arm_fat', 0), report_data.get('left_arm_lean', 0), report_data.get('left_arm_bmc', 0),
            report_data.get('right_leg_fat', 0), report_data.get('right_leg_lean', 0), report_data.get('right_leg_bmc', 0),
            report_data.get('left_leg_fat', 0), report_data.get('left_leg_lean', 0), report_data.get('left_leg_bmc', 0),
            report_data.get('trunk_fat', 0), report_data.get('trunk_lean', 0), report_data.get('trunk_bmc', 0),
            report_data['created_by'], report_data['is_published']
        ))
        
        if 'images' in report_data and report_data['images']:
            pdf_generator = OptimizedPlaywrightPDFGenerator()
            success = pdf_generator._save_report_images(report_data['report_id'], report_data['images'])
            if not success:
                st.warning("⚠️ Some images failed to save to database")
        
        # Save AP-Spine measurements
        for measurement in report_data.get('ap_spine_measurements', []):
            cursor.execute("""
                INSERT INTO ap_spine_measurements (report_id, region, bmd, t_score, z_score)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                report_data['report_id'], measurement['region'], 
                measurement['bmd'], measurement['t_score'], measurement['z_score']
            ))
        
        # Save Femur measurements
        for measurement in report_data.get('femur_measurements', []):
            cursor.execute("""
                INSERT INTO femur_measurements (report_id, side, region, bmd, t_score, z_score)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (
                report_data['report_id'], measurement['side'], measurement['region'],
                measurement['bmd'], measurement['t_score'], measurement['z_score']
            ))
        
        conn.commit()
        
        # Save initial version
        version_saved = save_report_version(
            report_data['report_id'], 
            report_data, 
            report_data['created_by'], 
            "Initial version"
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        if conn:
            conn.rollback()
        st.error(f"❌ General Error saving report: {str(e)}")
        return False
def prepare_report_data(db_report):
    """Prepare report data for PDF generation with all fields - FIXED VERSION"""
    if isinstance(db_report, dict):
        # Get AP-Spine measurements
        ap_spine_measurements = []
        right_femur_measurements = []
        left_femur_measurements = []
        
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM ap_spine_measurements WHERE report_id = %s", (db_report.get('report_id'),))
            ap_spine_measurements = cursor.fetchall()
            
            # Get Femur measurements
            cursor.execute("SELECT * FROM femur_measurements WHERE report_id = %s", (db_report.get('report_id'),))
            femur_measurements = cursor.fetchall()
            
            # Separate right and left femur measurements
            for measurement in femur_measurements:
                if measurement['side'] == 'RIGHT':
                    right_femur_measurements.append(measurement)
                else:
                    left_femur_measurements.append(measurement)
            
            cursor.close()
            conn.close()
        
        # FIX: Use actual database values with proper fallbacks
        return {
            'patient_id': db_report.get('patient_id', ''),
            'report_id': db_report.get('report_id', ''),
            'patient_name': f"{db_report.get('first_name', '')} {db_report.get('last_name', '')}",
            'age': db_report.get('age', 36),
            'gender': db_report.get('gender', 'M'),
            'report_date': db_report.get('report_date').strftime('%d %b %Y') if hasattr(db_report.get('report_date'), 'strftime') else db_report.get('report_date', ''),
            'height': db_report.get('height', 171),
            'total_mass': db_report.get('total_mass', 0.0),
            'fat_mass': db_report.get('fat_mass', 0.0),
            'lean_mass': db_report.get('lean_mass', 0.0),
            'bone_mass': db_report.get('bone_mass', 0.0),  # FIX: Use actual value
            'body_fat_percentage': db_report.get('body_fat_percentage', 0.0),
            'muscle_mass_almi': db_report.get('muscle_mass_almi', 0.0),
            'bone_density_t_score': db_report.get('bone_density_t_score', 0.0),
            'visceral_fat_area': db_report.get('visceral_fat_area', 0.0),
            'ag_ratio': db_report.get('ag_ratio', 0.0),
            'ffmi': db_report.get('ffmi', 0.0),  # FIX: Use actual value
            'fracture_risk': db_report.get('fracture_risk', 'LOW'),  # FIX: Use actual value
            'muscle_loss_risk': db_report.get('muscle_loss_risk', 'LOW'),  # FIX: Use actual value
            'z_score': db_report.get('z_score', -0.6),
            
            # Regional composition
            'right_arm_fat': db_report.get('right_arm_fat', 3.2),
            'right_arm_lean': db_report.get('right_arm_lean', 2.8),
            'right_arm_bmc': db_report.get('right_arm_bmc', 0.15),
            'left_arm_fat': db_report.get('left_arm_fat', 3.1),
            'left_arm_lean': db_report.get('left_arm_lean', 2.7),
            'left_arm_bmc': db_report.get('left_arm_bmc', 0.14),
            'right_leg_fat': db_report.get('right_leg_fat', 8.5),
            'right_leg_lean': db_report.get('right_leg_lean', 7.2),
            'right_leg_bmc': db_report.get('right_leg_bmc', 0.45),
            'left_leg_fat': db_report.get('left_leg_fat', 8.3),
            'left_leg_lean': db_report.get('left_leg_lean', 7.1),
            'left_leg_bmc': db_report.get('left_leg_bmc', 0.44),
            'trunk_fat': db_report.get('trunk_fat', 18.5),
            'trunk_lean': db_report.get('trunk_lean', 25.8),
            'trunk_bmc': db_report.get('trunk_bmc', 0.85),
            
            # Measurements
            'ap_spine_measurements': ap_spine_measurements,
            'right_femur_measurements': right_femur_measurements,
            'left_femur_measurements': left_femur_measurements
        }

def update_existing_report(report_data):
    """Update an existing report in the database with better transaction handling"""
    conn = get_db_connection()
    if not conn:
        return False
        
    cursor = conn.cursor()
    try:
        # Set timeouts
        cursor.execute("SET SESSION innodb_lock_wait_timeout = 30")
        cursor.execute("SET SESSION wait_timeout = 30")
        
        # Start transaction
        conn.start_transaction()
        
        # Update main report
        cursor.execute("""
            UPDATE dexa_reports SET
                patient_id = %s,
                report_date = %s,
                height = %s,
                total_mass = %s,
                fat_mass = %s,
                lean_mass = %s,
                bone_mass = %s,
                body_fat_percentage = %s,
                muscle_mass_almi = %s,
                bone_density_t_score = %s,
                z_score = %s,
                visceral_fat_area = %s,
                ag_ratio = %s,
                ffmi = %s,
                fracture_risk = %s,
                muscle_loss_risk = %s,
                right_arm_fat = %s,
                right_arm_lean = %s,
                right_arm_bmc = %s,
                left_arm_fat = %s,
                left_arm_lean = %s,
                left_arm_bmc = %s,
                right_leg_fat = %s,
                right_leg_lean = %s,
                right_leg_bmc = %s,
                left_leg_fat = %s,
                left_leg_lean = %s,
                left_leg_bmc = %s,
                trunk_fat = %s,
                trunk_lean = %s,
                trunk_bmc = %s,
                is_published = %s,
                last_edited = CURRENT_TIMESTAMP,
                edit_count = edit_count + 1
            WHERE report_id = %s
        """, (
            report_data['patient_id'], report_data['report_date'], report_data['height'],
            report_data['total_mass'], report_data['fat_mass'], report_data['lean_mass'],
            report_data['bone_mass'], report_data['body_fat_percentage'], report_data['muscle_mass_almi'],
            report_data['bone_density_t_score'], report_data['z_score'], report_data['visceral_fat_area'],
            report_data['ag_ratio'], report_data['ffmi'], report_data['fracture_risk'],
            report_data['muscle_loss_risk'], report_data['right_arm_fat'], report_data['right_arm_lean'],
            report_data['right_arm_bmc'], report_data['left_arm_fat'], report_data['left_arm_lean'],
            report_data['left_arm_bmc'], report_data['right_leg_fat'], report_data['right_leg_lean'],
            report_data['right_leg_bmc'], report_data['left_leg_fat'], report_data['left_leg_lean'],
            report_data['left_leg_bmc'], report_data['trunk_fat'], report_data['trunk_lean'],
            report_data['trunk_bmc'], report_data['is_published'], report_data['report_id']
        ))
        
        conn.commit()
        return True
        
    except mysql.connector.Error as e:
        if e.errno == 1205:  # Lock wait timeout
            conn.rollback()
            return False
        else:
            conn.rollback()
            return False
    except Exception as e:
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

# =============================================================================
# STREAMLIT UI COMPONENTS - OPTIMIZED
# =============================================================================

def show_image_preview_page(image_data, title):
    """Show a full page preview for an image"""
    st.markdown(f"<h1 style='text-align: center;'>🔍 {title}</h1>", unsafe_allow_html=True)
    
    if image_data:
        try:
            # Display the image
            st.image(image_data, use_column_width=True)
            
            # Download button
            st.download_button(
                label="📥 Download Image",
                data=image_data.getvalue(),
                file_name=f"{title.replace(' ', '_')}.jpg",
                mime="image/jpeg"
            )
        except Exception as e:
            st.error(f"Error displaying image: {str(e)}")
    else:
        st.warning("No image data available")
    
    # Back button
    if st.button("← Back"):
        st.session_state.show_image_preview = False
        st.rerun()

def show_pdf_preview_page(pdf_bytes, title):
    """Show a full page preview for a PDF"""
    st.markdown(f"<h1 style='text-align: center;'>📄 {title}</h1>", unsafe_allow_html=True)
    
    if pdf_bytes:
        try:
            # Display PDF
            base64_pdf = base64.b64encode(pdf_bytes).decode('utf-8')
            pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="100%" height="800" type="application/pdf"></iframe>'
            st.markdown(pdf_display, unsafe_allow_html=True)
            
            # Download button
            st.download_button(
                label="📥 Download PDF",
                data=pdf_bytes,
                file_name=f"{title.replace(' ', '_')}.pdf",
                mime="application/pdf"
            )
        except Exception as e:
            st.error(f"Error displaying PDF: {str(e)}")
    else:
        st.warning("No PDF data available")
    
    # Back button
    if st.button("← Back"):
        st.session_state.show_pdf_preview = False
        st.rerun()

def create_eye_icon_button(label, key, help_text="Click to preview"):
    """Create a clickable eye icon button"""
    return st.button(
        f"👁️ {label}", 
        key=key,
        help=help_text,
        use_container_width=True
    )

def show_pdf_generation_options():
    """Minimal PDF options - Playwright is always used with A4"""
    # No UI elements, just return defaults
    use_exact_pdf = True
    page_size = "A4"
    
    return use_exact_pdf, page_size

def cleanup_session_state():
    """Clean up old generated PDFs to save memory"""
    max_pdfs_to_keep = 10
    current_pdfs = st.session_state.get('generated_pdfs', {})
    
    if len(current_pdfs) > max_pdfs_to_keep:
        # Keep only the most recent PDFs
        keys_to_keep = list(current_pdfs.keys())[-max_pdfs_to_keep:]
        st.session_state.generated_pdfs = {k: current_pdfs[k] for k in keys_to_keep}

def show_reports_lazy(reports, dexa_system, items_per_page=10):
    """Show reports with pagination to avoid rendering everything at once"""
    if not reports:
        st.info("No reports available.")
        return
    
    # Simple pagination
    page = st.number_input("Page", min_value=1, max_value=(len(reports) // items_per_page) + 1, value=1)
    start_idx = (page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    
    for report in reports[start_idx:end_idx]:
        with st.expander(f"📄 {report['first_name']} {report['last_name']} - {report['report_id']}"):
            # Only load basic info initially
            display_report_summary_quick(report)
            
            # Load detailed info on demand
            if st.button("View Details", key=f"details_{report['report_id']}"):
                display_full_report_details(report, dexa_system)

def display_report_summary_quick(report):
    """Quick summary without heavy computations"""
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Total Mass", f"{report.get('total_mass', 'N/A')} kg")
        st.metric("Body Fat %", f"{report.get('body_fat_percentage', 'N/A')}%")
    with col2:
        st.metric("Muscle Mass", f"{report.get('muscle_mass_almi', 'N/A')} kg/m²")
        st.metric("Status", "Published")

def display_full_report_details(report, dexa_system):
    """Display full report details when requested"""
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Total Mass", f"{report.get('total_mass', 'N/A')} kg")
        st.metric("Fat Mass", f"{report.get('fat_mass', 'N/A')} kg")
        st.metric("Lean Mass", f"{report.get('lean_mass', 'N/A')} kg")
        st.metric("Bone Mass", f"{report.get('bone_mass', 'N/A')} kg")
    
    with col2:
        st.metric("Body Fat %", f"{report.get('body_fat_percentage', 'N/A')}%")
        st.metric("Muscle Mass", f"{report.get('muscle_mass_almi', 'N/A')} kg/m²")
        st.metric("Bone Density", f"{report.get('bone_density_t_score', 'N/A')}")
        st.metric("Visceral Fat", f"{report.get('visceral_fat_area', 'N/A')} cm²")
    
    # PDF generation options
    col3, col4 = st.columns(2)
    with col3:
        if st.button(f"📄 Generate A4 PDF", key=f"full_a4_{report['report_id']}"):
            pdf_data = prepare_report_data(report)
            pdf_bytes = dexa_system.generate_pdf(pdf_data, 'A4')
            if pdf_bytes:
                st.download_button(
                    label="📥 Download A4",
                    data=pdf_bytes,
                    file_name=f"dexa_report_{report['report_id']}_A4.pdf",
                    mime="application/pdf",
                    key=f"full_dl_a4_{report['report_id']}"
                )
    
    with col4:
        if st.button(f"📄 Generate A5 PDF", key=f"full_a5_{report['report_id']}"):
            pdf_data = prepare_report_data(report)
            pdf_bytes = dexa_system.generate_pdf(pdf_data, 'A5')
            if pdf_bytes:
                st.download_button(
                    label="📥 Download A5",
                    data=pdf_bytes,
                    file_name=f"dexa_report_{report['report_id']}_A5.pdf",
                    mime="application/pdf",
                    key=f"full_dl_a5_{report['report_id']}"
                )

def create_new_report(pdf_generator):
    """Create new DEXA report with placeholder values and examples"""
    st.markdown('<div class="section-header">📝 Create New DEXA Report</div>', unsafe_allow_html=True)
    if 'generated_pdfs' not in st.session_state:
        st.session_state.generated_pdfs = {}
    
    # PDF Generation Options
    use_exact_pdf, page_size = show_pdf_generation_options()
    
    # Initialize form data
    form_data = {}
    
    with st.form("dexa_report_form", clear_on_submit=False):
        st.markdown('<div class="section-header">👤 Patient Information</div>', unsafe_allow_html=True)
        col1, col2 = st.columns(2)
        
        with col1:
            patient_id = st.text_input("🆔 Patient ID*", placeholder="e.g., PT-001234", help="Unique patient identifier")
            first_name = st.text_input("👤 First Name*", placeholder="e.g., John", help="Patient's first name")
            last_name = st.text_input("👤 Last Name*", placeholder="e.g., Smith", help="Patient's last name")
            age = st.number_input("🎂 Age*", min_value=1, max_value=120, value=None, placeholder="e.g., 45", help="Patient's age in years")
            gender = st.selectbox("⚧ Gender*", ["Select Gender", "M", "F"], index=0, help="Patient's gender")
        
        with col2:
            report_id = st.text_input("📋 Report ID*", placeholder="e.g., RPT-2024-001", help="Unique report identifier")
            report_date = st.date_input("📅 Report Date*", value=date.today())
            height = st.number_input("📏 Height (cm)*", min_value=100, max_value=250, value=None, placeholder="e.g., 175", help="Patient height in centimeters")
                
        st.markdown('<div class="section-header">⚖️ Body Composition</div>', unsafe_allow_html=True)
        col3, col4 = st.columns(2)
        
        with col3:
            total_mass = st.number_input("⚖️ Total Mass (kg)*", min_value=0.0, value=None, placeholder="e.g., 75.5", help="Total body mass in kilograms")
            fat_mass = st.number_input("🩸 Fat Mass (kg)*", min_value=0.0, value=None, placeholder="e.g., 25.3", help="Fat mass in kilograms")
            lean_mass = st.number_input("💪 Lean Mass (kg)*", min_value=0.0, value=None, placeholder="e.g., 45.2", help="Lean mass in kilograms")
            bone_mass = st.number_input("🦴 Bone Mass (kg)*", min_value=0.0, value=None, placeholder="e.g., 2.8", help="Bone mineral content in kilograms")
        
        with col4:
            body_fat_percentage = st.number_input("📊 Body Fat Percentage*", min_value=0.0, max_value=100.0, value=None, placeholder="e.g., 33.5", help="Body fat percentage")
            muscle_mass_almi = st.number_input("🏋️ Muscle Mass ALMI (kg/m²)*", min_value=0.0, value=None, placeholder="e.g., 7.8", help="Appendicular Lean Mass Index")
            bone_density_t_score = st.number_input("🦴 Bone Density T-Score*", value=None, placeholder="e.g., -1.2", help="Bone mineral density T-score")
            z_score = st.number_input("📈 Z-Score*", value=None, placeholder="e.g., -0.8", help="Bone mineral density Z-score")
        
        st.markdown('<div class="section-header">📈 Additional Metrics</div>', unsafe_allow_html=True)
        col5, col6 = st.columns(2)
        
        with col5:
            visceral_fat_area = st.number_input("🎯 Visceral Fat Area (cm²)*", min_value=0.0, value=None, placeholder="e.g., 120.5", help="Visceral adipose tissue area")
            ag_ratio = st.number_input("📐 A/G Ratio*", min_value=0.0, value=None, placeholder="e.g., 0.95", help="Android to Gynoid ratio")
            ffmi = st.number_input("💪 FFMI (kg/m²)*", min_value=0.0, value=None, placeholder="e.g., 18.5", help="Fat-Free Mass Index")
        
        with col6:
            fracture_risk = st.selectbox("⚠️ Fracture Risk*", ["Select Risk Level", "LOW", "MODERATE", "HIGH"], index=0, help="Fracture risk assessment")
            muscle_loss_risk = st.selectbox("💪 Muscle Loss Risk*", ["Select Risk Level", "LOW", "MODERATE", "HIGH"], index=0, help="Muscle loss risk assessment")
        
        # Regional Composition Data - ARMS
        st.markdown('<div class="section-header">💪 Arms Composition</div>', unsafe_allow_html=True)
        
        st.subheader("Right Arm")
        col7, col8, col9 = st.columns(3)
        with col7:
            right_arm_fat = st.number_input("Right Arm Fat (kg)", min_value=0.0, value=None, placeholder="e.g., 1.2", key="right_arm_fat")
        with col8:
            right_arm_lean = st.number_input("Right Arm Lean (kg)", min_value=0.0, value=None, placeholder="e.g., 3.5", key="right_arm_lean")
        with col9:
            right_arm_bmc = st.number_input("Right Arm BMC (kg)", min_value=0.0, value=None, placeholder="e.g., 0.25", key="right_arm_bmc")
        
        st.subheader("Left Arm")
        col10, col11, col12 = st.columns(3)
        with col10:
            left_arm_fat = st.number_input("Left Arm Fat (kg)", min_value=0.0, value=None, placeholder="e.g., 1.1", key="left_arm_fat")
        with col11:
            left_arm_lean = st.number_input("Left Arm Lean (kg)", min_value=0.0, value=None, placeholder="e.g., 3.4", key="left_arm_lean")
        with col12:
            left_arm_bmc = st.number_input("Left Arm BMC (kg)", min_value=0.0, value=None, placeholder="e.g., 0.24", key="left_arm_bmc")
        
        # Regional Composition Data - LEGS
        st.markdown('<div class="section-header">🦵 Legs Composition</div>', unsafe_allow_html=True)
        
        st.subheader("Right Leg")
        col13, col14, col15 = st.columns(3)
        with col13:
            right_leg_fat = st.number_input("Right Leg Fat (kg)", min_value=0.0, value=None, placeholder="e.g., 5.8", key="right_leg_fat")
        with col14:
            right_leg_lean = st.number_input("Right Leg Lean (kg)", min_value=0.0, value=None, placeholder="e.g., 8.2", key="right_leg_lean")
        with col15:
            right_leg_bmc = st.number_input("Right Leg BMC (kg)", min_value=0.0, value=None, placeholder="e.g., 0.68", key="right_leg_bmc")
        
        st.subheader("Left Leg")
        col16, col17, col18 = st.columns(3)
        with col16:
            left_leg_fat = st.number_input("Left Leg Fat (kg)", min_value=0.0, value=None, placeholder="e.g., 5.7", key="left_leg_fat")
        with col17:
            left_leg_lean = st.number_input("Left Leg Lean (kg)", min_value=0.0, value=None, placeholder="e.g., 8.1", key="left_leg_lean")
        with col18:
            left_leg_bmc = st.number_input("Left Leg BMC (kg)", min_value=0.0, value=None, placeholder="e.g., 0.67", key="left_leg_bmc")
        
        # Regional Composition Data - TRUNK
        st.markdown('<div class="section-header">🦺 Trunk Composition</div>', unsafe_allow_html=True)
        
        col19, col20, col21 = st.columns(3)
        with col19:
            trunk_fat = st.number_input("Trunk Fat (kg)", min_value=0.0, value=None, placeholder="e.g., 12.5", key="trunk_fat")
        with col20:
            trunk_lean = st.number_input("Trunk Lean (kg)", min_value=0.0, value=None, placeholder="e.g., 25.8", key="trunk_lean")
        with col21:
            trunk_bmc = st.number_input("Trunk BMC (kg)", min_value=0.0, value=None, placeholder="e.g., 0.95", key="trunk_bmc")
        
        # Medical Images Upload Section
        st.markdown('<div class="section-header">🖼️ Medical Images</div>', unsafe_allow_html=True)
        
        col_img1, col_img2 = st.columns(2)
        
        with col_img1:
            st.subheader("AP-Spine Image")
            ap_spine_image = st.file_uploader("Upload AP-Spine Image", type=['png', 'jpg', 'jpeg'], key="ap_spine", help="Anterior-Posterior spine DEXA image")
            
            st.subheader("Right Femur Image")
            right_femur_image = st.file_uploader("Upload Right Femur Image", type=['png', 'jpg', 'jpeg'], key="right_femur", help="Right femur DEXA image")
            
            st.subheader("Full Body Image")
            full_body_image = st.file_uploader("Upload Full Body Image", type=['png', 'jpg', 'jpeg'], key="full_body", help="Full body composition image")
        
        with col_img2:
            st.subheader("Left Femur Image")
            left_femur_image = st.file_uploader("Upload Left Femur Image", type=['png', 'jpg', 'jpeg'], key="left_femur", help="Left femur DEXA image")
            
            st.subheader("Fat Distribution Image")
            fat_distribution_image = st.file_uploader("Upload Fat Distribution Image", type=['png', 'jpg', 'jpeg'], key="fat_dist", help="Fat distribution analysis image")
        
        # AP-Spine Measurements
        st.markdown('<div class="section-header">📊 AP-Spine Measurements</div>', unsafe_allow_html=True)
        
        ap_spine_measurements = []
        spine_regions = ['L1', 'L2', 'L3', 'L4', 'L1-L4']
        
        for region in spine_regions:
            st.subheader(f"AP-Spine {region}")
            col_sp1, col_sp2, col_sp3 = st.columns(3)
            with col_sp1:
                bmd = st.number_input(f"BMD {region} (g/cm²)", min_value=0.0, value=None, placeholder="e.g., 1.15", key=f"spine_bmd_{region}")
            with col_sp2:
                t_score = st.number_input(f"T-Score {region}", value=None, placeholder="e.g., -0.8", key=f"spine_t_{region}")
            with col_sp3:
                z_score = st.number_input(f"Z-Score {region}", value=None, placeholder="e.g., 0.2", key=f"spine_z_{region}")
            
            ap_spine_measurements.append({
                'region': region,
                'bmd': bmd,
                't_score': t_score,
                'z_score': z_score
            })
        
        # Femur Measurements
        st.markdown('<div class="section-header">📊 Femur Measurements</div>', unsafe_allow_html=True)
        
        femur_measurements = []
        femur_regions = ['NECK', 'TOTAL']
        
        st.subheader("Right Femur")
        for region in femur_regions:
            col_fm1, col_fm2, col_fm3 = st.columns(3)
            with col_fm1:
                bmd = st.number_input(f"BMD Right {region} (g/cm²)", min_value=0.0, value=None, placeholder="e.g., 0.95", key=f"rfemur_bmd_{region}")
            with col_fm2:
                t_score = st.number_input(f"T-Score Right {region}", value=None, placeholder="e.g., -1.1", key=f"rfemur_t_{region}")
            with col_fm3:
                z_score = st.number_input(f"Z-Score Right {region}", value=None, placeholder="e.g., -0.5", key=f"rfemur_z_{region}")
            
            femur_measurements.append({
                'side': 'RIGHT',
                'region': region,
                'bmd': bmd,
                't_score': t_score,
                'z_score': z_score
            })
        
        st.subheader("Left Femur")
        for region in femur_regions:
            col_fm4, col_fm5, col_fm6 = st.columns(3)
            with col_fm4:
                bmd = st.number_input(f"BMD Left {region} (g/cm²)", min_value=0.0, value=None, placeholder="e.g., 0.98", key=f"lfemur_bmd_{region}")
            with col_fm5:
                t_score = st.number_input(f"T-Score Left {region}", value=None, placeholder="e.g., -0.9", key=f"lfemur_t_{region}")
            with col_fm6:
                z_score = st.number_input(f"Z-Score Left {region}", value=None, placeholder="e.g., -0.3", key=f"lfemur_z_{region}")
            
            femur_measurements.append({
                'side': 'LEFT',
                'region': region,
                'bmd': bmd,
                't_score': t_score,
                'z_score': z_score
            })
        
        # User assignment
        users = get_all_users_cached()
        user_options = {f"{u['full_name']} ({u['username']})": u['user_id'] for u in users if u['user_type'] == 'user'}
        if user_options:
            selected_user = st.selectbox("Assign to User", ["Select User"] + list(user_options.keys()))
            assign_to_user = user_options[selected_user] if selected_user != "Select User" else None
        else:
            assign_to_user = None
            st.info("No users available for assignment")
        
        # Submit buttons
        st.markdown("---")
        col20, col21 = st.columns(2)
        with col20:
            save_draft = st.form_submit_button("💾 Save as Draft", use_container_width=True)
        with col21:
            publish_report = st.form_submit_button("🚀 Publish Report", use_container_width=True)
    
    # Handle form submission OUTSIDE the form
    if save_draft or publish_report:
        # Validate required fields
        required_fields = {
            "Patient ID": patient_id,
            "Report ID": report_id,
            "First Name": first_name,
            "Last Name": last_name,
            "Age": age,
            "Gender": gender,
            "Height": height,
            "Total Mass": total_mass,
            "Fat Mass": fat_mass,
            "Lean Mass": lean_mass,
            "Bone Mass": bone_mass,
            "Body Fat Percentage": body_fat_percentage,
            "Muscle Mass ALMI": muscle_mass_almi,
            "Bone Density T-Score": bone_density_t_score,
            "Z-Score": z_score,
            "Visceral Fat Area": visceral_fat_area,
            "A/G Ratio": ag_ratio,
            "FFMI": ffmi,
            "Fracture Risk": fracture_risk,
            "Muscle Loss Risk": muscle_loss_risk
        }
        
        # Check for "Select..." options
        if gender == "Select Gender":
            st.error("❌ Please select a gender")
            st.stop()
        
        if fracture_risk == "Select Risk Level":
            st.error("❌ Please select fracture risk level")
            st.stop()
            
        if muscle_loss_risk == "Select Risk Level":
            st.error("❌ Please select muscle loss risk level")
            st.stop()
        
        missing_fields = [field for field, value in required_fields.items() if value is None or value == ""]
        if missing_fields:
            st.error(f"❌ Please fill in all required fields: {', '.join(missing_fields)}")
        else:
            # Check if report ID already exists
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("SELECT report_id FROM dexa_reports WHERE report_id = %s", (report_id,))
                existing_report = cursor.fetchone()
                cursor.close()
                conn.close()
                
                if existing_report:
                    st.error(f"❌ Report ID {report_id} already exists.")
                else:
                    # Prepare image data
                    image_data = {
                        'ap_spine': ap_spine_image,
                        'right_femur': right_femur_image,
                        'left_femur': left_femur_image,
                        'body_outline': full_body_image,
                        'fat_distribution': fat_distribution_image
                    }
                    
                    # Convert None values to 0 for regional composition (optional fields)
                    regional_fields = {
                        'right_arm_fat': right_arm_fat or 0,
                        'right_arm_lean': right_arm_lean or 0,
                        'right_arm_bmc': right_arm_bmc or 0,
                        'left_arm_fat': left_arm_fat or 0,
                        'left_arm_lean': left_arm_lean or 0,
                        'left_arm_bmc': left_arm_bmc or 0,
                        'right_leg_fat': right_leg_fat or 0,
                        'right_leg_lean': right_leg_lean or 0,
                        'right_leg_bmc': right_leg_bmc or 0,
                        'left_leg_fat': left_leg_fat or 0,
                        'left_leg_lean': left_leg_lean or 0,
                        'left_leg_bmc': left_leg_bmc or 0,
                        'trunk_fat': trunk_fat or 0,
                        'trunk_lean': trunk_lean or 0,
                        'trunk_bmc': trunk_bmc or 0
                    }
                    
                    # Save report data
                    report_data = {
                        'patient_id': patient_id,
                        'report_id': report_id,
                        'first_name': first_name,
                        'last_name': last_name,
                        'age': age,
                        'gender': gender,
                        'height': height,
                        'report_date': report_date,
                        'total_mass': total_mass,
                        'fat_mass': fat_mass,
                        'lean_mass': lean_mass,
                        'bone_mass': bone_mass,
                        'body_fat_percentage': body_fat_percentage,
                        'muscle_mass_almi': muscle_mass_almi,
                        'bone_density_t_score': bone_density_t_score,
                        'z_score': z_score,
                        'visceral_fat_area': visceral_fat_area,
                        'ag_ratio': ag_ratio,
                        'ffmi': ffmi,
                        'fracture_risk': fracture_risk,
                        'muscle_loss_risk': muscle_loss_risk,
                        
                        # Regional composition fields
                        **regional_fields,
                        
                        # Image data
                        'images': image_data,
                        
                        # Measurement data
                        'ap_spine_measurements': ap_spine_measurements,
                        'femur_measurements': femur_measurements,
                        
                        'hospital_id': st.session_state.user['hospital_id'],
                        'created_by': st.session_state.user['user_id'],
                        'is_published': bool(publish_report)
                    }
                    
                    if save_report_data(report_data):
                        if publish_report:
                            # Mark as published
                            publish_report_func(report_id)
                            
                            # Generate PDFs and store them in session state for download outside the form
                            pdf_report_data = prepare_report_data(report_data)
                            
                            # Generate PDF with selected options
                            pdf_bytes = pdf_generator.generate_pdf(pdf_report_data, page_size)
                            if pdf_bytes:
                                success = pdf_generator.save_to_supabase_storage(
                                    pdf_bytes, 
                                    f"{report_data['report_id']}_{page_size}.pdf",
                                    report_data['report_id'],
                                    page_size
                                )
                                if success:
                                    st.session_state.generated_pdfs[f"{page_size.lower()}_{report_id}"] = pdf_bytes
                                    st.success(f"✅ PDF generated and stored! Report ID: {report_id}")
                                else:
                                    st.error("❌ PDF generated but failed to save to cloud storage")
                            else:
                                st.error("❌ Failed to generate PDF")
                            
                            st.success("✅ Report published successfully!")
                        else:
                            st.success("✅ Report saved as draft!")
                        
                        # Link to user if specified
                        if assign_to_user:
                            link_patient_to_user(patient_id, assign_to_user)
                            st.success("✅ Report linked to user!")
                        
                        if publish_report:
                            st.balloons()
                    else:
                        st.error("❌ Failed to save report data to database")
    
    # Handle image previews AFTER form submission (outside the form)
    if any([ap_spine_image, right_femur_image, left_femur_image, full_body_image, fat_distribution_image]):
        st.markdown("---")
        st.subheader("🖼️ Image Previews")
        
        preview_images = [
            ("AP-Spine", ap_spine_image),
            ("Right Femur", right_femur_image),
            ("Left Femur", left_femur_image),
            ("Full Body", full_body_image),
            ("Fat Distribution", fat_distribution_image)
        ]
        
        for name, img in preview_images:
            if img is not None:
                col_preview1, col_preview2 = st.columns([3, 1])
                with col_preview1:
                    st.write(f"**{name}** - {img.size // 1024} KB")
                with col_preview2:
                    if st.button(f"👁️ Preview {name}", key=f"preview_{name}"):
                        st.session_state.show_image_preview = True
                        st.session_state.preview_image_data = img
                        st.session_state.preview_image_title = name
                        st.rerun()

# =============================================================================
# MAIN APPLICATION WITH OPTIMIZATIONS
# =============================================================================

def initialize_session_state():
    """Initialize session state efficiently"""
    default_states = {
        'user': None,
        'show_register': False,
        'show_hospital_registration': False,
        'current_page': "🏠 Dashboard",
        'editing_report': None,
        'edit_report_data': None,
        'generated_pdfs': {},
        'show_image_preview': False,
        'show_pdf_preview': False,
        'preview_image_data': None,
        'preview_image_title': "",
        'preview_pdf_data': None,
        'preview_pdf_title': "",
        'show_help_section': False,
        'last_cleanup': time.time()
    }
    
    for key, value in default_states.items():
        if key not in st.session_state:
            st.session_state[key] = value

def main():
    # Custom CSS for colorful UI
    st.markdown("""
        <style>
        .main-header {
            font-size: 3rem;
            font-weight: bold;
            background: linear-gradient(45deg, #FF6B6B, #4ECDC4, #45B7D1, #96CEB4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-align: center;
            margin-bottom: 2rem;
        }
        .hospital-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 0.5rem 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .section-header {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2E86AB;
            border-left: 5px solid #2E86AB;
            padding-left: 1rem;
            margin: 2rem 0 1rem 0;
            background: linear-gradient(90deg, #F8F9FA, #FFFFFF);
            padding: 1rem;
            border-radius: 0.5rem;
        }
        .metric-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 0.5rem 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .metric-value {
            font-size: 2rem;
            font-weight: bold;
            margin: 0.5rem 0;
        }
        .metric-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        .success-box {
            background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 1rem 0;
            border-left: 5px solid #2E8B57;
        }
        .warning-box {
            background: linear-gradient(135deg, #f7971e 0%, #ffd200 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 1rem 0;
            border-left: 5px solid #FF8C00;
        }
        .danger-box {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 1rem 0;
            border-left: 5px solid #DC143C;
        }
        .info-box {
            background: linear-gradient(135deg, #4ECDC4 0%, #44A08D 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 1rem 0;
            border-left: 5px solid #008B8B;
        }
        .error-box {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);
            padding: 1.5rem;
            border-radius: 1rem;
            color: white;
            margin: 1rem 0;
            border-left: 5px solid #DC143C;
        }
        .stButton>button {
            background: linear-gradient(45deg, #FF6B6B, #4ECDC4);
            color: white;
            border: none;
            padding: 0.5rem 2rem;
            border-radius: 0.5rem;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .stButton>button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .eye-button {
            background: linear-gradient(45deg, #FFA726, #FF9800) !important;
        }
        </style>
    """, unsafe_allow_html=True)

    st.set_page_config(
        page_title="Hospital DEXA Report System",
        page_icon="🏥",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    initialize_session_state()
    
    # Quick health check
    if not perform_quick_health_check():
        st.warning("⚠️ System is running in degraded mode. Some features may be slow.")
    
    # Initialize system with Optimized PDF Generator
    pdf_generator = OptimizedPlaywrightPDFGenerator()
    
    # Periodic cleanup
    if time.time() - st.session_state.last_cleanup > 300:  # Every 5 minutes
        cleanup_session_state()
        st.session_state.last_cleanup = time.time()
    
    # Check authentication
    if not st.session_state.user:
        if st.session_state.show_hospital_registration:
            show_hospital_registration_page()
        elif st.session_state.show_register:
            show_user_registration_page()
        else:
            show_login_page()
        return
    
    # Handle preview pages first
    if st.session_state.show_image_preview:
        show_image_preview_page(st.session_state.preview_image_data, st.session_state.preview_image_title)
        return
        
    if st.session_state.show_pdf_preview:
        show_pdf_preview_page(st.session_state.preview_pdf_data, st.session_state.preview_pdf_title)
        return
    
    # User is authenticated - show main application
    user = st.session_state.user
    
    # Show hospital header
    show_hospital_header(user)
    
    # Different interfaces for admin vs regular users
    if user['user_type'] == 'admin':
        show_admin_interface(pdf_generator, user)
    else:
        show_user_interface(pdf_generator, user)

def show_hospital_header(user):
    """Show hospital information header - BOLD & SPACIOUS"""
    st.markdown(f'<div class="main-header">🏥 {user["hospital_name"]}</div>', unsafe_allow_html=True)
    
    # Bold font with maximum spacing
    st.markdown(f"""
        <div style="text-align: center; color: #555; margin: 1.2rem 0 2.5rem 0; 
                    font-size: 1.3rem; font-weight: 500; line-height: 1.8;">
            <span style="margin: 0 2.5rem;">📍 {user["address"]}</span> • 
            <span style="margin: 0 2.5rem;">📞 {user["phone_number"]}</span> • 
            <span style="margin: 0 2.5rem;">✉️ {user["email"]}</span>
        </div>
    """, unsafe_allow_html=True)
    
    # User info and logout
    col1, col2 = st.columns([3, 1])
    with col1:
        st.write(f"Welcome, **{user['full_name']}** ({user['user_type'].title()})")
    with col2:
        if st.button("🚪 Logout"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()

def show_admin_interface(pdf_generator, user):
    """Admin interface with sidebar navigation - INCLUDES VERSION HISTORY"""
    with st.sidebar:
        st.markdown("### 📊 Navigation")
        menu_options = ["🏠 Dashboard", "📝 Data Management", "👥 User Management", "📋 Reports", "🔄 Version History", "💾 Storage"]
        selected_page = st.selectbox("Choose Section", menu_options, key="admin_nav")
        
        if selected_page != st.session_state.current_page:
            st.session_state.current_page = selected_page
            st.rerun()
    
    # Route to appropriate section
    if st.session_state.current_page == "🏠 Dashboard":
        show_admin_dashboard(pdf_generator, user)
    elif st.session_state.current_page == "📝 Data Management":
        show_admin_data_management(pdf_generator, user)
    elif st.session_state.current_page == "👥 User Management":
        show_admin_user_management(user)
    elif st.session_state.current_page == "📋 Reports":
        show_admin_reports(pdf_generator, user)
    elif st.session_state.current_page == "🔄 Version History":
        show_version_history()
    elif st.session_state.current_page == "💾 Storage":
        show_cloud_storage(pdf_generator)

def show_user_interface(pdf_generator, user):
    """User interface - single page for regular users WITH VERSION ACCESS"""
    if st.session_state.current_page == "🔄 Version History":
        show_version_history()
    else:
        show_user_reports_page(pdf_generator, user)

def show_admin_dashboard(pdf_generator, user):
    """Enhanced system dashboard with hospital-specific recent reports"""
    st.markdown('<div class="section-header">📊 System Dashboard</div>', unsafe_allow_html=True)
    
    # Get database stats FOR CURRENT HOSPITAL ONLY
    conn = get_db_connection()
    hospital_id = user['hospital_id']
    
    if conn:
        cursor = conn.cursor(dictionary=True)
        
        # Count patients for current hospital
        cursor.execute("SELECT COUNT(*) as count FROM patients WHERE hospital_id = %s", (hospital_id,))
        total_patients = cursor.fetchone()
        
        # Count reports for current hospital
        cursor.execute("SELECT COUNT(*) as count FROM dexa_reports WHERE hospital_id = %s", (hospital_id,))
        total_reports = cursor.fetchone()
        
        # Count today's reports for current hospital
        cursor.execute("SELECT COUNT(*) as count FROM dexa_reports WHERE report_date = %s AND hospital_id = %s", 
                      (date.today(), hospital_id))
        today_reports = cursor.fetchone()
        
        cursor.close()
        conn.close()
    else:
        total_patients = {'count': 0}
        total_reports = {'count': 0}
        today_reports = {'count': 0}
    
    # Get user-specific reports (already hospital-filtered)
    user_reports = get_user_reports_optimized(st.session_state.user['user_id'], hospital_id)
    
    # Get Supabase storage info FOR CURRENT HOSPITAL ONLY
    file_count, total_size_mb = pdf_generator.get_storage_info()
    
    # Display hospital-specific metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Hospital Patients</div>
                <div class="metric-value">{total_patients['count']}</div>
                <div>👥 {user['hospital_name']}</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Hospital Reports</div>
                <div class="metric-value">{total_reports['count']}</div>
                <div>📋 {user['hospital_name']}</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Today's Reports</div>
                <div class="metric-value">{today_reports['count']}</div>
                <div>📅 {user['hospital_name']}</div>
            </div>
        """, unsafe_allow_html=True)
    
    col4, col5, col6 = st.columns(3)
    
    with col4:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">My Reports</div>
                <div class="metric-value">{len(user_reports)}</div>
                <div>📄 Accessible</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col5:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Cloud PDFs</div>
                <div class="metric-value">{file_count}</div>
                <div>☁️ Stored</div>
            </div>
        """, unsafe_allow_html=True)
    
    with col6:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Storage Used</div>
                <div class="metric-value">{total_size_mb:.1f} MB</div>
                <div>📦 Cloud</div>
            </div>
        """, unsafe_allow_html=True)
    
    # Recent Reports Section - HOSPITAL-SPECIFIC
    st.markdown('<div class="section-header">📋 Recent Hospital PDFs</div>', unsafe_allow_html=True)
    
    # Get stored files from Supabase FOR CURRENT HOSPITAL ONLY
    stored_files = pdf_generator.list_stored_reports()
    hospital_files = [f for f in stored_files if f.get('hospital_id') == hospital_id]
    recent_files = hospital_files[:5] if hospital_files else []
    
    if recent_files:
        for i, file in enumerate(recent_files):
            col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
            
            with col1:
                st.markdown(f"""
                    <div class="info-box">
                        <strong>{file['filename']}</strong><br>
                        <small>Report: {file.get('first_name', 'N/A')} {file.get('last_name', 'N/A')} ({file['report_id']})</small><br>
                        <small>Size: {file['file_size_kb']} KB | Format: {file['file_format']} | Uploaded: {file['created_at'].strftime('%Y-%m-%d %H:%M')}</small><br>
                        <small>URL: <a href="{file['file_url']}" target="_blank">View File</a></small>
                    </div>
                """, unsafe_allow_html=True)
            
            with col2:
                # Download from URL
                st.download_button(
                    label="📥 Download",
                    data=requests.get(file['file_url']).content,
                    file_name=file['filename'],
                    mime="application/pdf",
                    key=f"download_{file['unique_filename']}_{i}",
                    use_container_width=True
                )
            
            with col3:
                # Preview with eye icon
                if create_eye_icon_button("Preview", f"cloud_storage_preview_{file['unique_filename']}_{i}"):
                    st.session_state.show_pdf_preview = True
                    st.session_state.preview_pdf_data = requests.get(file['file_url']).content
                    st.session_state.preview_pdf_title = f"Cloud Storage: {file['filename']}"
                    st.rerun()
            
            with col4:
                st.write(f"🔗 [Link]({file['file_url']})")
        
        if len(hospital_files) > 5:
            st.info(f"📚 Showing 5 most recent PDFs out of {len(hospital_files)} total hospital files.")
    else:
        st.markdown(f"""
            <div class="warning-box">
                No PDF reports stored yet for {user['hospital_name']}.
            </div>
        """, unsafe_allow_html=True)

def show_admin_data_management(pdf_generator, user):
    """Admin data management interface - EXCLUSIVE data entry point"""
    st.markdown('<div class="section-header">📊 Admin Data Management</div>', unsafe_allow_html=True)
    
    tab1, tab2, tab3 = st.tabs(["➕ Create New Report", "📋 Manage Reports", "🔄 Version History"])
    
    with tab1:
        create_new_report(pdf_generator)
    
    with tab2:
        manage_reports(pdf_generator)
    
    with tab3:
        show_version_history()

def manage_reports(pdf_generator):
    """Manage existing reports with editing capabilities - INCLUDES VERSION ACCESS"""
    st.markdown('<div class="section-header">📋 Manage Hospital Reports</div>', unsafe_allow_html=True)
    
    hospital_id = st.session_state.user['hospital_id']
    hospital_name = st.session_state.user['hospital_name']
    
    # Show hospital context
    st.info(f"🏥 Viewing reports for: **{hospital_name}**")
    
    # Check if we're in edit mode for a specific report
    if st.session_state.editing_report:
        show_edit_report_form(pdf_generator, st.session_state.editing_report, st.session_state.edit_report_data)
        return
    
    # Show today's reports for editing
    st.subheader(f"📝 Today's Reports - {hospital_name}")
    
    todays_reports = get_todays_reports()
    
    if todays_reports:
        for i, report in enumerate(todays_reports):
            with st.expander(f"📄 {report['first_name']} {report['last_name']} - {report['report_id']} ({'Published' if report['is_published'] else 'Draft'})"):
                display_report_summary(report)
                
                # Show creation date and version info
                created_date = report['created_at'].date() if hasattr(report['created_at'], 'date') else report['created_at']
                st.caption(f"📅 Created: {created_date}")
                
                # Show version count with clickable link
                versions = get_report_versions(report['report_id'])
                version_count = len(versions)
                
                col_info1, col_info2 = st.columns(2)
                with col_info1:
                    st.info(f"📚 {version_count} versions available")
                with col_info2:
                    if st.button(f"👁️ View Versions", key=f"view_versions_{report['report_id']}_{i}"):
                        st.session_state.current_page = "🔄 Version History"
                        st.session_state.selected_report_for_versions = report['report_id']
                        st.rerun()
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button(f"✏️ Edit Report", key=f"edit_{report['report_id']}_{i}"):
                        st.session_state.editing_report = report['report_id']
                        st.session_state.edit_report_data = report
                        st.rerun()
                
                with col2:
                    if not report['is_published']:
                        if st.button(f"🚀 Publish", key=f"publish_{report['report_id']}_{i}"):
                            if publish_report_func(report['report_id']):
                                st.markdown('<div class="success-box">✅ Report published!</div>', unsafe_allow_html=True)
                                # Generate PDFs on publish
                                pdf_report_data = prepare_report_data(report)
                                generate_and_store_report_pdfs(pdf_generator, pdf_report_data)
                                st.rerun()
                    else:
                        st.button(f"✅ Published", key=f"published_{report['report_id']}_{i}", disabled=True)
                
                with col3:
                    if st.button(f"📄 Generate PDFs", key=f"generate_{report['report_id']}_{i}"):
                        pdf_report_data = prepare_report_data(report)
                        generate_and_store_report_pdfs(pdf_generator, pdf_report_data)
                        st.markdown('<div class="success-box">✅ PDFs generated! Check download buttons below.</div>', unsafe_allow_html=True)
                
                # Show download buttons if PDFs exist for this report
                st.markdown("---")
                st.markdown("### 📄 PDF Options")
                col_dl1, col_dl2 = st.columns(2)
                
                with col_dl1:
                    a4_key = f"a4_{report['report_id']}"
                    if a4_key in st.session_state.generated_pdfs:
                        col_dl1a, col_dl1b, col_dl1c = st.columns([2, 1, 1])
                        with col_dl1a:
                            st.write("**A4 Format PDF**")
                        with col_dl1b:
                            st.download_button(
                                label="📥 Download",
                                data=st.session_state.generated_pdfs[a4_key],
                                file_name=f"dexa_report_{report['report_id']}_A4.pdf",
                                mime="application/pdf",
                                key=f"dl_a4_{report['report_id']}_{i}"
                            )
                        with col_dl1c:
                            if create_eye_icon_button("Preview", f"preview_a4_{report['report_id']}_{i}"):
                                st.session_state.show_pdf_preview = True
                                st.session_state.preview_pdf_data = st.session_state.generated_pdfs[a4_key]
                                st.session_state.preview_pdf_title = f"DEXA Report {report['report_id']} - A4"
                                st.rerun()
                    else:
                        st.info("A4 PDF not generated yet")
                
                with col_dl2:
                    a5_key = f"a5_{report['report_id']}"
                    if a5_key in st.session_state.generated_pdfs:
                        col_dl2a, col_dl2b, col_dl2c = st.columns([2, 1, 1])
                        with col_dl2a:
                            st.write("**A5 Format PDF**")
                        with col_dl2b:
                            st.download_button(
                                label="📥 Download",
                                data=st.session_state.generated_pdfs[a5_key],
                                file_name=f"dexa_report_{report['report_id']}_A5.pdf",
                                mime="application/pdf",
                                key=f"dl_a5_{report['report_id']}_{i}"
                            )
                        with col_dl2c:
                            if create_eye_icon_button("Preview", f"preview_a5_{report['report_id']}_{i}"):
                                st.session_state.show_pdf_preview = True
                                st.session_state.preview_pdf_data = st.session_state.generated_pdfs[a5_key]
                                st.session_state.preview_pdf_title = f"DEXA Report {report['report_id']} - A5"
                                st.rerun()
                    else:
                        st.info("A5 PDF not generated yet")
    else:
        st.info(f"No reports created today for {hospital_name}.")
    
    # Show all published reports (read-only)
    st.subheader(f"📋 All Published Reports - {hospital_name}")
    
    all_reports = get_user_reports_optimized(st.session_state.user['user_id'], hospital_id)
    
    if all_reports:
        for i, report in enumerate(all_reports):
            with st.expander(f"📋 {report['first_name']} {report['last_name']} - {report['report_id']} (Published: {report.get('published_at', 'N/A')})"):
                display_report_summary(report)
                
                # Show version count with access
                versions = get_report_versions(report['report_id'])
                version_count = len(versions)
                
                col_ver1, col_ver2 = st.columns(2)
                with col_ver1:
                    st.info(f"📚 {version_count} versions available")
                with col_ver2:
                    if st.button(f"👁️ View All Versions", key=f"view_all_versions_{report['report_id']}_{i}"):
                        st.session_state.current_page = "🔄 Version History"
                        st.session_state.selected_report_for_versions = report['report_id']
                        st.rerun()
                
                # Show stored files
                stored_files = get_supabase_files_by_report(report['report_id'])
                if stored_files:
                    st.subheader("📁 Stored PDF Files")
                    for j, file in enumerate(stored_files):
                        col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
                        with col1:
                            st.write(f"**{file['filename']}** ({file['file_format']}) - {file['file_size_kb']:.1f} KB")
                        with col2:
                            st.download_button(
                                label="📥 Download",
                                data=requests.get(file['file_url']).content,
                                file_name=file['filename'],
                                mime="application/pdf",
                                key=f"download_{file['unique_filename']}_{i}_{j}"
                            )
                        with col3:
                            if create_eye_icon_button("Preview", f"cloud_preview_{file['unique_filename']}_{i}_{j}"):
                                st.session_state.show_pdf_preview = True
                                st.session_state.preview_pdf_data = requests.get(file['file_url']).content
                                st.session_state.preview_pdf_title = f"Cloud: {file['filename']}"
                                st.rerun()
                        with col4:
                            st.write(f"🔗 [Link]({file['file_url']})")
                
                # Export options
                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"📄 A4 PDF", key=f"export_a4_{report['report_id']}_{i}"):
                        export_report_pdf(pdf_generator, report['report_id'], 'A4')
                with col2:
                    if st.button(f"📄 A5 PDF", key=f"export_a5_{report['report_id']}_{i}"):
                        export_report_pdf(pdf_generator, report['report_id'], 'A5')
    else:
        st.info(f"No published reports found for {hospital_name}.")

def display_report_summary(report):
    """Display report summary"""
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Total Mass", f"{report.get('total_mass', 'N/A')} kg")
        st.metric("Fat Mass", f"{report.get('fat_mass', 'N/A')} kg")
        st.metric("Lean Mass", f"{report.get('lean_mass', 'N/A')} kg")
        st.metric("Bone Mass", f"{report.get('bone_mass', 'N/A')} kg")
    
    with col2:
        st.metric("Body Fat %", f"{report.get('body_fat_percentage', 'N/A')}%")
        st.metric("Muscle Mass", f"{report.get('muscle_mass_almi', 'N/A')} kg/m²")
        st.metric("Bone Density", f"{report.get('bone_density_t_score', 'N/A')}")
        st.metric("Visceral Fat", f"{report.get('visceral_fat_area', 'N/A')} cm²")

def generate_and_store_report_pdfs(pdf_generator, report_data):
    """Generate and store PDF reports in cloud - without download buttons"""
    report_id = report_data['report_id']
    
    # Generate A4 PDF
    try:
        pdf_a4 = pdf_generator.generate_pdf(report_data, 'A4')
        if pdf_a4:
            success = pdf_generator.save_to_supabase_storage(
                pdf_a4, 
                f"{report_id}_A4.pdf",
                report_id,
                'A4'
            )
            st.session_state.generated_pdfs[f"a4_{report_id}"] = pdf_a4
            st.success("✅ A4 PDF generated and stored!")
        else:
            st.error("❌ A4 PDF generation returned no data. Check logs for errors.")
    except Exception as e:
        # Surface the full traceback to the UI to aid debugging
        tb = traceback.format_exc()
        st.error(f"❌ Error generating A4 PDF: {str(e)}")
        st.text(tb)
    
    # Generate A5 PDF
    try:
        pdf_a5 = pdf_generator.generate_pdf(report_data, 'A5')
        if pdf_a5:
            success = pdf_generator.save_to_supabase_storage(
                pdf_a5, 
                f"{report_id}_A5.pdf",
                report_id,
                'A5'
            )
            st.session_state.generated_pdfs[f"a5_{report_id}"] = pdf_a5
            st.success("✅ A5 PDF generated and stored!")
        else:
            st.error("❌ Failed to generate A5 PDF")
    except Exception as e:
        tb = traceback.format_exc()
        st.error(f"❌ Error generating A5 PDF: {str(e)}")
        st.text(tb)

def export_report_pdf(pdf_generator, report_id, page_size):
    """Export existing report as PDF with proper error handling"""
    try:
        # Fetch report data
        conn = get_db_connection()
        if not conn:
            return
            
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT r.*, p.first_name, p.last_name, p.age, p.gender
            FROM dexa_reports r 
            JOIN patients p ON r.patient_id = p.patient_id 
            WHERE r.report_id = %s
        """, (report_id,))
        
        report = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if not report:
            st.error(f"❌ Report {report_id} not found")
            return
        
        # Prepare report data for PDF generation
        report_data = prepare_report_data(report)
        
        # Generate PDF
        pdf_bytes = pdf_generator.generate_pdf(report_data, page_size)
        
        if pdf_bytes:
            # Store in session state for later access
            session_key = f"{page_size.lower()}_{report_id}"
            st.session_state.generated_pdfs[session_key] = pdf_bytes
            
            # Create download and view buttons - UPDATED WITH EYE ICONS
            col1, col2, col3 = st.columns([1, 1, 1])
            with col1:
                st.download_button(
                    label=f"📥 Download {page_size}",
                    data=pdf_bytes,
                    file_name=f"dexa_report_{report_id}_{page_size}.pdf",
                    mime="application/pdf",
                    key=f"export_{report_id}_{page_size}_{datetime.now().timestamp()}"
                )
            with col2:
                if create_eye_icon_button(f"Preview {page_size}", f"export_preview_{report_id}_{page_size}"):
                    st.session_state.show_pdf_preview = True
                    st.session_state.preview_pdf_data = pdf_bytes
                    st.session_state.preview_pdf_title = f"Export: {report_id} - {page_size}"
                    st.rerun()
            with col3:
                st.info(f"✅ {page_size} PDF Ready")
            
            # Also save to cloud storage
            success = pdf_generator.save_to_supabase_storage(
                pdf_bytes, 
                f"{report_id}_{page_size}.pdf",
                report_id,
                page_size
            )
            
            if success:
                st.success(f"✅ {page_size} PDF saved to cloud storage")
            else:
                st.warning(f"⚠️ PDF generated but cloud save failed")
        else:
            st.error("❌ Failed to generate PDF")
            
    except Exception as e:
        st.error(f"❌ Error exporting report: {str(e)}")

def show_edit_report_form(pdf_generator, report_id, report_data):
    """Show form for editing an existing report"""
    st.markdown(f'<div class="section-header">✏️ Edit Report: {report_id}</div>', unsafe_allow_html=True)
    
    # Get current images
    current_images = pdf_generator._get_report_images_for_pdf(report_id)
    
    # Safely extract values from report_data with defaults
    def safe_get(key, default=None):
        return report_data.get(key, default)
    
    # Initialize form - this must be at the top level
    with st.form("edit_report_form"):
        st.markdown('<div class="section-header">👤 Patient Information</div>', unsafe_allow_html=True)
        col1, col2 = st.columns(2)
        
        with col1:
            patient_id = st.text_input("🆔 Patient ID*", value=safe_get('patient_id', '000480'))
            first_name = st.text_input("👤 First Name*", value=safe_get('first_name', 'BRI'))
            last_name = st.text_input("👤 Last Name*", value=safe_get('last_name', 'K'))
            age = st.number_input("🎂 Age*", min_value=1, max_value=120, value=int(safe_get('age', 36)))
            gender = st.selectbox("⚧ Gender*", ["M", "F"], index=0 if safe_get('gender', 'M') == 'M' else 1)
        
        with col2:
            report_id_display = st.text_input("📋 Report ID*", value=report_id, disabled=True)
            report_date = st.date_input("📅 Report Date*", value=safe_get('report_date', date.today()))
            height = st.number_input("📏 Height (cm)*", min_value=100.0, max_value=250.0, value=float(safe_get('height', 171.0)))
        
        st.markdown('<div class="section-header">⚖️ Body Composition</div>', unsafe_allow_html=True)
        col3, col4 = st.columns(2)
        
        with col3:
            total_mass = st.number_input("⚖️ Total Mass (kg)*", min_value=0.0, value=float(safe_get('total_mass', 104.6)))
            fat_mass = st.number_input("🩸 Fat Mass (kg)*", min_value=0.0, value=float(safe_get('fat_mass', 39.79)))
            lean_mass = st.number_input("💪 Lean Mass (kg)*", min_value=0.0, value=float(safe_get('lean_mass', 61.84)))
            bone_mass = st.number_input("🦴 Bone Mass (kg)*", min_value=0.0, value=float(safe_get('bone_mass', 2.94)))
        
        with col4:
            body_fat_percentage = st.number_input("📊 Body Fat Percentage*", min_value=0.0, max_value=100.0, value=float(safe_get('body_fat_percentage', 38.0)))
            muscle_mass_almi = st.number_input("🏋️ Muscle Mass ALMI (kg/m²)*", min_value=0.0, value=float(safe_get('muscle_mass_almi', 10.23)))
            bone_density_t_score = st.number_input("🦴 Bone Density T-Score*", value=float(safe_get('bone_density_t_score', -0.6)))
            z_score = st.number_input("📈 Z-Score*", value=float(safe_get('z_score', -0.6)))
        
        st.markdown('<div class="section-header">📈 Additional Metrics</div>', unsafe_allow_html=True)
        col5, col6 = st.columns(2)
        
        with col5:
            visceral_fat_area = st.number_input("🎯 Visceral Fat Area (cm²)*", min_value=0.0, value=float(safe_get('visceral_fat_area', 170.0)))
            ag_ratio = st.number_input("📐 A/G Ratio*", min_value=0.0, value=float(safe_get('ag_ratio', 1.23)))
            ffmi = st.number_input("💪 FFMI (kg/m²)*", min_value=0.0, value=float(safe_get('ffmi', 20.67)))
        
        with col6:
            # FIX: Handle case sensitivity and provide safe default index
            fracture_risk_options = ["LOW", "MODERATE", "HIGH"]
            current_fracture_risk = safe_get('fracture_risk', 'LOW').upper()
            fracture_risk_index = fracture_risk_options.index(current_fracture_risk) if current_fracture_risk in fracture_risk_options else 0
            fracture_risk = st.selectbox("⚠️ Fracture Risk*", fracture_risk_options, index=fracture_risk_index)
            
            muscle_loss_risk_options = ["LOW", "MODERATE", "HIGH"]
            current_muscle_loss_risk = safe_get('muscle_loss_risk', 'LOW').upper()
            muscle_loss_risk_index = muscle_loss_risk_options.index(current_muscle_loss_risk) if current_muscle_loss_risk in muscle_loss_risk_options else 0
            muscle_loss_risk = st.selectbox("💪 Muscle Loss Risk*", muscle_loss_risk_options, index=muscle_loss_risk_index)
        
        # Regional Composition Data
        st.markdown('<div class="section-header">💪 Arms Composition</div>', unsafe_allow_html=True)
        
        col7, col8, col9 = st.columns(3)
        with col7:
            right_arm_fat = st.number_input("Right Arm Fat (kg)", min_value=0.0, value=float(safe_get('right_arm_fat', 3.2)))
            left_arm_fat = st.number_input("Left Arm Fat (kg)", min_value=0.0, value=float(safe_get('left_arm_fat', 3.1)))
        with col8:
            right_arm_lean = st.number_input("Right Arm Lean (kg)", min_value=0.0, value=float(safe_get('right_arm_lean', 2.8)))
            left_arm_lean = st.number_input("Left Arm Lean (kg)", min_value=0.0, value=float(safe_get('left_arm_lean', 2.7)))
        with col9:
            right_arm_bmc = st.number_input("Right Arm BMC (kg)", min_value=0.0, value=float(safe_get('right_arm_bmc', 0.15)))
            left_arm_bmc = st.number_input("Left Arm BMC (kg)", min_value=0.0, value=float(safe_get('left_arm_bmc', 0.14)))
        
        st.markdown('<div class="section-header">🦵 Legs Composition</div>', unsafe_allow_html=True)
        
        col10, col11, col12 = st.columns(3)
        with col10:
            right_leg_fat = st.number_input("Right Leg Fat (kg)", min_value=0.0, value=float(safe_get('right_leg_fat', 8.5)))
            left_leg_fat = st.number_input("Left Leg Fat (kg)", min_value=0.0, value=float(safe_get('left_leg_fat', 8.3)))
        with col11:
            right_leg_lean = st.number_input("Right Leg Lean (kg)", min_value=0.0, value=float(safe_get('right_leg_lean', 7.2)))
            left_leg_lean = st.number_input("Left Leg Lean (kg)", min_value=0.0, value=float(safe_get('left_leg_lean', 7.1)))
        with col12:
            right_leg_bmc = st.number_input("Right Leg BMC (kg)", min_value=0.0, value=float(safe_get('right_leg_bmc', 0.45)))
            left_leg_bmc = st.number_input("Left Leg BMC (kg)", min_value=0.0, value=float(safe_get('left_leg_bmc', 0.44)))
        
        st.markdown('<div class="section-header">🦺 Trunk Composition</div>', unsafe_allow_html=True)
        
        col13, col14, col15 = st.columns(3)
        with col13:
            trunk_fat = st.number_input("Trunk Fat (kg)", min_value=0.0, value=float(safe_get('trunk_fat', 18.5)))
        with col14:
            trunk_lean = st.number_input("Trunk Lean (kg)", min_value=0.0, value=float(safe_get('trunk_lean', 25.8)))
        with col15:
            trunk_bmc = st.number_input("Trunk BMC (kg)", min_value=0.0, value=float(safe_get('trunk_bmc', 0.85)))
        
        # Image Update Section
        st.markdown('<div class="section-header">🖼️ Update Medical Images</div>', unsafe_allow_html=True)
        
        col_img1, col_img2 = st.columns(2)
        
        with col_img1:
            st.subheader("AP-Spine Image")
            new_ap_spine = st.file_uploader("Update AP-Spine Image", type=['png', 'jpg', 'jpeg'], key="edit_ap_spine")
            if current_images.get('ap_spine'):
                st.info("✅ Current image exists")
            
            st.subheader("Right Femur Image")
            new_right_femur = st.file_uploader("Update Right Femur Image", type=['png', 'jpg', 'jpeg'], key="edit_right_femur")
            if current_images.get('right_femur'):
                st.info("✅ Current image exists")
            
            st.subheader("Full Body Image")
            new_full_body = st.file_uploader("Update Full Body Image", type=['png', 'jpg', 'jpeg'], key="edit_full_body")
            if current_images.get('full_body'):
                st.info("✅ Current image exists")
        
        with col_img2:
            st.subheader("Left Femur Image")
            new_left_femur = st.file_uploader("Update Left Femur Image", type=['png', 'jpg', 'jpeg'], key="edit_left_femur")
            if current_images.get('left_femur'):
                st.info("✅ Current image exists")
            
            st.subheader("Fat Distribution Image")
            new_fat_dist = st.file_uploader("Update Fat Distribution Image", type=['png', 'jpg', 'jpeg'], key="edit_fat_dist")
            if current_images.get('fat_distribution'):
                st.info("✅ Current image exists")
        
        # Edit reason for version control
        edit_reason = st.text_area("📝 Edit Reason", placeholder="Describe what changes you made and why...", help="This will be recorded in the version history")
        
        # FIX: Create a container to store form data and handle submission
        form_data = {}
        
        # Store all form data in a dictionary
        form_data.update({
            'patient_id': patient_id,
            'first_name': first_name,
            'last_name': last_name,
            'age': age,
            'gender': gender,
            'report_date': report_date,
            'height': height,
            'total_mass': total_mass,
            'fat_mass': fat_mass,
            'lean_mass': lean_mass,
            'bone_mass': bone_mass,
            'body_fat_percentage': body_fat_percentage,
            'muscle_mass_almi': muscle_mass_almi,
            'bone_density_t_score': bone_density_t_score,
            'z_score': z_score,
            'visceral_fat_area': visceral_fat_area,
            'ag_ratio': ag_ratio,
            'ffmi': ffmi,
            'fracture_risk': fracture_risk,
            'muscle_loss_risk': muscle_loss_risk,
            'right_arm_fat': right_arm_fat,
            'right_arm_lean': right_arm_lean,
            'right_arm_bmc': right_arm_bmc,
            'left_arm_fat': left_arm_fat,
            'left_arm_lean': left_arm_lean,
            'left_arm_bmc': left_arm_bmc,
            'right_leg_fat': right_leg_fat,
            'right_leg_lean': right_leg_lean,
            'right_leg_bmc': right_leg_bmc,
            'left_leg_fat': left_leg_fat,
            'left_leg_lean': left_leg_lean,
            'left_leg_bmc': left_leg_bmc,
            'trunk_fat': trunk_fat,
            'trunk_lean': trunk_lean,
            'trunk_bmc': trunk_bmc,
            'edit_reason': edit_reason,
            'new_ap_spine': new_ap_spine,
            'new_right_femur': new_right_femur,
            'new_left_femur': new_left_femur,
            'new_full_body': new_full_body,
            'new_fat_dist': new_fat_dist
        })
        
        # FIX: Proper submit buttons inside the form
        col16, col17, col18 = st.columns(3)
        
        with col16:
            save_changes = st.form_submit_button("💾 Save Changes")
        with col17:
            save_and_publish = st.form_submit_button("🚀 Save & Publish")
        with col18:
            cancel_edit = st.form_submit_button("❌ Cancel Edit")
        
        # Handle form submission INSIDE the form context
        if save_changes or save_and_publish:
            # Validate required fields
            required_fields = {
                "Patient ID": form_data['patient_id'],
                "First Name": form_data['first_name'],
                "Last Name": form_data['last_name'],
                "Height": form_data['height']
            }
            
            missing_fields = [field for field, value in required_fields.items() if not value]
            if missing_fields:
                st.error(f"❌ Please fill in: {', '.join(missing_fields)}")
                st.stop()
            
            if not form_data['edit_reason'].strip():
                st.error("❌ Please provide an edit reason for version control")
                st.stop()
            
            # Prepare updated report data
            updated_report_data = {
                'patient_id': form_data['patient_id'],
                'report_id': report_id,
                'first_name': form_data['first_name'],
                'last_name': form_data['last_name'],
                'age': form_data['age'],
                'gender': form_data['gender'],
                'height': form_data['height'],
                'report_date': form_data['report_date'],
                'total_mass': form_data['total_mass'],
                'fat_mass': form_data['fat_mass'],
                'lean_mass': form_data['lean_mass'],
                'bone_mass': form_data['bone_mass'],
                'body_fat_percentage': form_data['body_fat_percentage'],
                'muscle_mass_almi': form_data['muscle_mass_almi'],
                'bone_density_t_score': form_data['bone_density_t_score'],
                'z_score': form_data['z_score'],
                'visceral_fat_area': form_data['visceral_fat_area'],
                'ag_ratio': form_data['ag_ratio'],
                'ffmi': form_data['ffmi'],
                'fracture_risk': form_data['fracture_risk'],
                'muscle_loss_risk': form_data['muscle_loss_risk'],
                
                # Regional composition
                'right_arm_fat': form_data['right_arm_fat'],
                'right_arm_lean': form_data['right_arm_lean'],
                'right_arm_bmc': form_data['right_arm_bmc'],
                'left_arm_fat': form_data['left_arm_fat'],
                'left_arm_lean': form_data['left_arm_lean'],
                'left_arm_bmc': form_data['left_arm_bmc'],
                'right_leg_fat': form_data['right_leg_fat'],
                'right_leg_lean': form_data['right_leg_lean'],
                'right_leg_bmc': form_data['right_leg_bmc'],
                'left_leg_fat': form_data['left_leg_fat'],
                'left_leg_lean': form_data['left_leg_lean'],
                'left_leg_bmc': form_data['left_leg_bmc'],
                'trunk_fat': form_data['trunk_fat'],
                'trunk_lean': form_data['trunk_lean'],
                'trunk_bmc': form_data['trunk_bmc'],
                
                'created_by': st.session_state.user['user_id'],
                'is_published': bool(save_and_publish) or safe_get('is_published', False)
            }
            
            # Update report in database
            if update_existing_report(updated_report_data):
                # Save new images if any were uploaded
                update_images = {
                    'ap_spine': form_data['new_ap_spine'],
                    'right_femur': form_data['new_right_femur'],
                    'left_femur': form_data['new_left_femur'],
                    'full_body': form_data['new_full_body'],
                    'fat_distribution': form_data['new_fat_dist']
                }
                
                # Remove None values (images that weren't updated)
                update_images = {k: v for k, v in update_images.items() if v is not None}
                
                if update_images:
                    pdf_generator._save_report_images(report_id, update_images)
                
                # Save new version
                save_report_version(
                    report_id, 
                    updated_report_data, 
                    st.session_state.user['user_id'], 
                    form_data['edit_reason']
                )
                
                if save_and_publish:
                    publish_report_func(report_id)
                    st.success("✅ Report updated, new version saved, and published!")
                    # Generate new PDFs
                    pdf_report_data = prepare_report_data(updated_report_data)
                    generate_and_store_report_pdfs(pdf_generator, pdf_report_data)
                else:
                    st.success("✅ Report updated and new version saved!")
                
                # Clear edit state
                st.session_state.editing_report = None
                st.session_state.edit_report_data = None
                
                st.balloons()
                st.rerun()
        
        # Handle cancel inside form context
        if cancel_edit:
            st.session_state.editing_report = None
            st.session_state.edit_report_data = None
            st.rerun()


def show_admin_reports(pdf_generator, user):
    """Admin reports view"""
    st.markdown('<div class="section-header">📋 All Reports</div>', unsafe_allow_html=True)
    
    reports = get_user_reports_optimized(user['user_id'], user['hospital_id'])
    
    if reports:
        for report in reports:
            with st.expander(f"📄 {report['first_name']} {report['last_name']} - {report['report_id']} ({report['report_date']})"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Total Mass", f"{report.get('total_mass', 'N/A')} kg")
                    st.metric("Fat Mass", f"{report.get('fat_mass', 'N/A')} kg")
                    st.metric("Lean Mass", f"{report.get('lean_mass', 'N/A')} kg")
                
                with col2:
                    st.metric("Body Fat %", f"{report.get('body_fat_percentage', 'N/A')}%")
                    st.metric("Muscle Mass", f"{report.get('muscle_mass_almi', 'N/A')} kg/m²")
                    st.metric("Bone Density", f"{report.get('bone_density_t_score', 'N/A')}")
                
                # PDF generation
                col3, col4 = st.columns(2)
                with col3:
                    if st.button(f"📄 Generate A4 PDF", key=f"a4_{report['report_id']}"):
                        pdf_data = prepare_report_data(report)
                        pdf_bytes = pdf_generator.generate_pdf(pdf_data, 'A4')
                        if pdf_bytes:
                            st.download_button(
                                label="📥 Download A4 PDF",
                                data=pdf_bytes,
                                file_name=f"dexa_report_{report['report_id']}_A4.pdf",
                                mime="application/pdf",
                                key=f"dl_a4_{report['report_id']}"
                            )
                
                with col4:
                    if st.button(f"📄 Generate A5 PDF", key=f"a5_{report['report_id']}"):
                        pdf_data = prepare_report_data(report)
                        pdf_bytes = pdf_generator.generate_pdf(pdf_data, 'A5')
                        if pdf_bytes:
                            st.download_button(
                                label="📥 Download A5 PDF",
                                data=pdf_bytes,
                                file_name=f"dexa_report_{report['report_id']}_A5.pdf",
                                mime="application/pdf",
                                key=f"dl_a5_{report['report_id']}"
                            )
    else:
        st.info("No reports found.")

def show_version_history():
    """Show complete version history for reports - ACCESSIBLE TO BOTH ADMIN AND USERS"""
    st.markdown('<div class="section-header">🔄 Report Version History</div>', unsafe_allow_html=True)
    
    user_id = st.session_state.user['user_id']
    hospital_id = st.session_state.user['hospital_id']
    user_type = st.session_state.user['user_type']
    hospital_name = st.session_state.user['hospital_name']
    
    # Initialize PDF generator
    pdf_generator = OptimizedPlaywrightPDFGenerator()
    
    # Tab layout for different views
    tab1, tab2 = st.tabs(["📋 By Report", "🕒 All Versions"])
    
    with tab1:
        show_version_history_by_report(user_id, hospital_id, user_type, hospital_name, pdf_generator)
    
    with tab2:
        show_all_versions(user_id, hospital_id, user_type, hospital_name, pdf_generator)

def show_version_history_by_report(user_id, hospital_id, user_type, hospital_name, pdf_generator):
    """Show version history organized by report with PDF downloads"""
    # Get all reports the user can access
    accessible_reports = get_user_reports_optimized(user_id, hospital_id)
    
    if accessible_reports:
        report_options = {f"{r['first_name']} {r['last_name']} - {r['report_id']}": r['report_id'] for r in accessible_reports}
        selected_report = st.selectbox(f"Select Report from {hospital_name}", list(report_options.keys()))
        
        if selected_report:
            report_id = report_options[selected_report]
            versions = get_report_versions(report_id)
            
            if versions:
                st.subheader(f"Version History for {selected_report}")
                st.info(f"📚 Found {len(versions)} versions for this report")
                
                for version in versions:
                    with st.expander(f"Version {version['version_number']} - {version['created_at'].strftime('%Y-%m-%d %H:%M')} ({version['editor_name'] or version['edited_by']})", expanded=False):
                        display_version_details(version, pdf_generator)
            else:
                st.info("No version history available for this report.")
    else:
        st.info(f"No reports available to show version history for {hospital_name}.")

def show_all_versions(user_id, hospital_id, user_type, hospital_name, pdf_generator):
    """Show all versions across all accessible reports with PDF downloads"""
    versions = get_accessible_report_versions(user_id, hospital_id, user_type)
    
    if versions:
        st.subheader(f"All Version History - {hospital_name}")
        st.info(f"📚 Total versions found: {len(versions)}")
        
        # Group versions by report
        reports_dict = {}
        for version in versions:
            report_key = f"{version['first_name']} {version['last_name']} - {version['report_id']}"
            if report_key not in reports_dict:
                reports_dict[report_key] = []
            reports_dict[report_key].append(version)
        
        # Display versions grouped by report
        for report_name, report_versions in reports_dict.items():
            with st.expander(f"📄 {report_name} ({len(report_versions)} versions)"):
                for version in sorted(report_versions, key=lambda x: x['version_number'], reverse=True):
                    display_version_details(version, pdf_generator)
                    st.markdown("---")
    else:
        st.info(f"No version history available for {hospital_name}.")
def display_version_details(version, pdf_generator=None):
    """Display detailed version information with PDF download"""
    # Create a unique key prefix using version_id and timestamp to avoid duplicates
    unique_key = f"v{version['version_id']}_{int(time.time()*1000)}"
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write(f"**Version Number:** {version['version_number']}")
        st.write(f"**Created:** {version['created_at'].strftime('%Y-%m-%d %H:%M:%S')}")
    
    with col2:
        st.write(f"**Edited by:** {version['editor_name'] or version['edited_by']}")
        st.write(f"**Edit Reason:** {version['edit_reason']}")
    
    # PDF Download Section - FIXED WITH UNIQUE KEYS
    st.markdown("### 📄 PDF Download")
    col_dl1, col_dl2 = st.columns(2)
    
    with col_dl1:
        if st.button(f"📥 Generate A4 PDF", key=f"gen_a4_{unique_key}"):
            with st.spinner(f"Generating Version {version['version_number']} PDF..."):
                pdf_bytes = generate_version_pdf(version, pdf_generator, 'A4')
                if pdf_bytes:
                    # Store in session state for download
                    session_key = f"version_{version['version_id']}_a4"
                    st.session_state.generated_pdfs[session_key] = pdf_bytes
                    st.success("✅ A4 PDF generated!")
                    st.rerun()
    
    with col_dl2:
        if st.button(f"📥 Generate A5 PDF", key=f"gen_a5_{unique_key}"):
            with st.spinner(f"Generating Version {version['version_number']} PDF..."):
                pdf_bytes = generate_version_pdf(version, pdf_generator, 'A5')
                if pdf_bytes:
                    # Store in session state for download
                    session_key = f"version_{version['version_id']}_a5"
                    st.session_state.generated_pdfs[session_key] = pdf_bytes
                    st.success("✅ A5 PDF generated!")
                    st.rerun()
    
    # Show download buttons if PDFs are already generated
    a4_key = f"version_{version['version_id']}_a4"
    a5_key = f"version_{version['version_id']}_a5"
    
    if a4_key in st.session_state.generated_pdfs:
        col_dl_a4_1, col_dl_a4_2 = st.columns([1, 1])
        with col_dl_a4_1:
            st.download_button(
                label="📥 Download A4 PDF",
                data=st.session_state.generated_pdfs[a4_key],
                file_name=f"version_{version['version_number']}_{version['report_id']}_A4.pdf",
                mime="application/pdf",
                key=f"dl_a4_{unique_key}"
            )
        with col_dl_a4_2:
            if st.button(f"👁️ Preview A4", key=f"preview_a4_{unique_key}"):
                st.session_state.show_pdf_preview = True
                st.session_state.preview_pdf_data = st.session_state.generated_pdfs[a4_key]
                st.session_state.preview_pdf_title = f"Version {version['version_number']} - {version['report_id']} - A4"
                st.rerun()
    
    if a5_key in st.session_state.generated_pdfs:
        col_dl_a5_1, col_dl_a5_2 = st.columns([1, 1])
        with col_dl_a5_1:
            st.download_button(
                label="📥 Download A5 PDF",
                data=st.session_state.generated_pdfs[a5_key],
                file_name=f"version_{version['version_number']}_{version['report_id']}_A5.pdf",
                mime="application/pdf",
                key=f"dl_a5_{unique_key}"
            )
        with col_dl_a5_2:
            if st.button(f"👁️ Preview A5", key=f"preview_a5_{unique_key}"):
                st.session_state.show_pdf_preview = True
                st.session_state.preview_pdf_data = st.session_state.generated_pdfs[a5_key]
                st.session_state.preview_pdf_title = f"Version {version['version_number']} - {version['report_id']} - A5"
                st.rerun()
    
    # Display version data
    try:
        report_data = json.loads(version['report_data'])
        
        st.markdown("### 📊 Report Data")
        
        # Basic info
        col3, col4 = st.columns(2)
        with col3:
            st.write("**Patient Info**")
            st.write(f"Name: {report_data.get('first_name', 'N/A')} {report_data.get('last_name', 'N/A')}")
            st.write(f"Age: {report_data.get('age', 'N/A')}")
            st.write(f"Gender: {report_data.get('gender', 'N/A')}")
        
        with col4:
            st.write("**Report Info**")
            st.write(f"Report ID: {report_data.get('report_id', 'N/A')}")
            st.write(f"Report Date: {report_data.get('report_date', 'N/A')}")
            st.write(f"Height: {report_data.get('height', 'N/A')} cm")
        
        # Body composition metrics
        st.markdown("### ⚖️ Body Composition")
        col5, col6, col7, col8 = st.columns(4)
        
        with col5:
            if 'total_mass' in report_data:
                st.metric("Total Mass", f"{report_data.get('total_mass', 0)} kg")
            if 'fat_mass' in report_data:
                st.metric("Fat Mass", f"{report_data.get('fat_mass', 0)} kg")
        
        with col6:
            if 'lean_mass' in report_data:
                st.metric("Lean Mass", f"{report_data.get('lean_mass', 0)} kg")
            if 'bone_mass' in report_data:
                st.metric("Bone Mass", f"{report_data.get('bone_mass', 0)} kg")
        
        with col7:
            if 'body_fat_percentage' in report_data:
                st.metric("Body Fat %", f"{report_data.get('body_fat_percentage', 0)}%")
            if 'muscle_mass_almi' in report_data:
                st.metric("Muscle Mass", f"{report_data.get('muscle_mass_almi', 0)} kg/m²")
        
        with col8:
            if 'bone_density_t_score' in report_data:
                st.metric("Bone Density", f"{report_data.get('bone_density_t_score', 0)}")
            if 'visceral_fat_area' in report_data:
                st.metric("Visceral Fat", f"{report_data.get('visceral_fat_area', 0)} cm²")
        
        # Additional metrics if available
        if any(key in report_data for key in ['ag_ratio', 'ffmi', 'fracture_risk', 'muscle_loss_risk']):
            st.markdown("### 📈 Additional Metrics")
            col9, col10 = st.columns(2)
            
            with col9:
                if 'ag_ratio' in report_data:
                    st.metric("A/G Ratio", f"{report_data.get('ag_ratio', 0)}")
                if 'ffmi' in report_data:
                    st.metric("FFMI", f"{report_data.get('ffmi', 0)} kg/m²")
            
            with col10:
                if 'fracture_risk' in report_data:
                    st.metric("Fracture Risk", report_data.get('fracture_risk', 'N/A'))
                if 'muscle_loss_risk' in report_data:
                    st.metric("Muscle Loss Risk", report_data.get('muscle_loss_risk', 'N/A'))
                    
    except Exception as e:
        st.error(f"Error displaying version data: {str(e)}")

def generate_version_pdf(version, pdf_generator, page_size='A4'):
    """Generate PDF from version data"""
    try:
        report_data = json.loads(version['report_data'])
        
        # Ensure all required fields are present for PDF generation
        required_fields = {
            'patient_name': f"{report_data.get('first_name', '')} {report_data.get('last_name', '')}".strip(),
            'patient_id': report_data.get('patient_id', version['report_id']),
            'report_id': version['report_id'],
            'report_date': report_data.get('report_date', version['created_at'].strftime('%Y-%m-%d')),
            'age': report_data.get('age', 'N/A'),
            'gender': report_data.get('gender', 'N/A'),
            'height': report_data.get('height', 0),
            'total_mass': report_data.get('total_mass', 0),
            'fat_mass': report_data.get('fat_mass', 0),
            'lean_mass': report_data.get('lean_mass', 0),
            'bone_mass': report_data.get('bone_mass', 0),
            'body_fat_percentage': report_data.get('body_fat_percentage', 0),
            'muscle_mass_almi': report_data.get('muscle_mass_almi', 0),
            'bone_density_t_score': report_data.get('bone_density_t_score', 0),
            'visceral_fat_area': report_data.get('visceral_fat_area', 0),
            'ag_ratio': report_data.get('ag_ratio', 0),
            'ffmi': report_data.get('ffmi', 0),
            'fracture_risk': report_data.get('fracture_risk', 'LOW'),
            'muscle_loss_risk': report_data.get('muscle_loss_risk', 'LOW'),
            'z_score': report_data.get('z_score', 0)
        }
        
        # Add version-specific information to the report data
        report_data['version_info'] = f"Version {version['version_number']} - {version['created_at'].strftime('%Y-%m-%d %H:%M')}"
        report_data['edit_reason'] = version['edit_reason']
        report_data['edited_by'] = version.get('editor_name', version['edited_by'])
        
        # Generate PDF using your existing PDF generator
        if pdf_generator:
            return pdf_generator.generate_pdf_with_timeout(report_data, page_size, timeout=30)
        else:
            # Fallback: create a simple PDF generator instance
            pdf_gen = OptimizedPlaywrightPDFGenerator()
            return pdf_gen.generate_pdf_with_timeout(report_data, page_size, timeout=30)
            
    except Exception as e:
        st.error(f"Error generating version PDF: {str(e)}")
        return None
def show_user_reports_page(pdf_generator, user):
    """User reports page with version access"""
    st.markdown('<div class="section-header">📋 My Reports</div>', unsafe_allow_html=True)
    
    # User info and logout with help button in header
    col4, col5, col6 = st.columns([3, 1, 1])
    with col4:
        st.write(f"Welcome, **{user['full_name']}** ({user['user_type'].title()})")
    with col5:
        # Version history access for users
        if st.button("🔄 Versions", use_container_width=True):
            st.session_state.current_page = "🔄 Version History"
            st.rerun()
    with col6:
        if st.button("🚪 Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
    
    # Show help section if toggled
    if st.session_state.get('show_help_section', False):
        st.markdown("""
        **For technical issues or report access problems, please contact your hospital administrator:**
        
        - **Hospital:** {hospital_name}
        - **Phone:** {phone_number}
        - **Email:** {email}
        - **Address:** {address}
        
        **Common Issues:**
        - Can't see your reports? Contact admin to link your account
        - PDF download not working? Try refreshing the page
        - Forgot password? Admin can reset it for you
        
        **Note:** Only published reports are visible here. If you don't see expected reports, 
        they may still be in draft status or not assigned to your account.
        
        """.format(
            hospital_name=user['hospital_name'],
            phone_number=user['phone_number'],
            email=user['email'],
            address=user['address']
        ))
    
    # User reports - main content
    reports = get_user_reports_optimized(user['user_id'], user['hospital_id'])
    
    if reports:
        for report in reports:
            with st.expander(f"📄 {report['first_name']} {report['last_name']} - {report['report_id']} ({report['report_date']})"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Total Mass", f"{report.get('total_mass', 'N/A')} kg")
                    st.metric("Body Fat %", f"{report.get('body_fat_percentage', 'N/A')}%")
                    st.metric("Muscle Mass", f"{report.get('muscle_mass_almi', 'N/A')} kg/m²")
                
                with col2:
                    st.metric("Bone Density", f"{report.get('bone_density_t_score', 'N/A')}")
                    st.metric("Visceral Fat", f"{report.get('visceral_fat_area', 'N/A')} cm²")
                    st.metric("Status", "Published")
                
                # Show version access for users
                versions = get_report_versions(report['report_id'])
                if versions:
                    st.info(f"📚 {len(versions)} versions available")
                    if st.button(f"👁️ View Version History", key=f"user_versions_{report['report_id']}"):
                        st.session_state.current_page = "🔄 Version History"
                        st.session_state.selected_report_for_versions = report['report_id']
                        st.rerun()
                
                # PDF download
                col3, col4 = st.columns(2)
                with col3:
                    if st.button(f"📄 Download A4 PDF", key=f"user_a4_{report['report_id']}"):
                        pdf_data = prepare_report_data(report)
                        pdf_bytes = pdf_generator.generate_pdf(pdf_data, 'A4')
                        if pdf_bytes:
                            st.download_button(
                                label="📥 Download A4",
                                data=pdf_bytes,
                                file_name=f"dexa_report_{report['report_id']}_A4.pdf",
                                mime="application/pdf",
                                key=f"user_dl_a4_{report['report_id']}"
                            )
                
                with col4:
                    if st.button(f"📄 Download A5 PDF", key=f"user_a5_{report['report_id']}"):
                        pdf_data = prepare_report_data(report)
                        pdf_bytes = pdf_generator.generate_pdf(pdf_data, 'A5')
                        if pdf_bytes:
                            st.download_button(
                                label="📥 Download A5",
                                data=pdf_bytes,
                                file_name=f"dexa_report_{report['report_id']}_A5.pdf",
                                mime="application/pdf",
                                key=f"user_dl_a5_{report['report_id']}"
                            )
    else:
        st.info("""
        No reports available. This could be because:
        
        - No reports have been published yet
        - Your account hasn't been linked to any patients
        - Reports are still in draft status
        
        Please contact your hospital administrator if you believe you should have access to reports.
        """)

def show_cloud_storage(pdf_generator):
    """Show cloud PDF storage management - HOSPITAL SPECIFIC"""
    st.markdown('<div class="section-header">☁️ Cloud PDF Storage (Supabase)</div>', unsafe_allow_html=True)
    
    hospital_id = st.session_state.user['hospital_id']
    hospital_name = st.session_state.user['hospital_name']
    
    # Storage info - HOSPITAL SPECIFIC
    stored_files = pdf_generator.list_stored_reports()
    hospital_files = [f for f in stored_files if f.get('hospital_id') == hospital_id]
    total_size_mb = sum(file['file_size_kb'] for file in hospital_files) / 1024
    
    st.markdown(f"""
        <div class="info-box">
            <strong>🏥 Hospital:</strong> {hospital_name}<br>
            <strong>☁️ Storage Provider:</strong> Supabase<br>
            <strong>💾 Total Size:</strong> {total_size_mb:.2f} MB<br>
            <strong>📄 Files:</strong> {len(hospital_files)} PDF reports
        </div>
    """, unsafe_allow_html=True)
    
    # List stored reports - HOSPITAL SPECIFIC
    if hospital_files:
        st.markdown(f'<div class="section-header">📋 Stored PDF Reports ({len(hospital_files)} files)</div>', unsafe_allow_html=True)
        
        for i, file in enumerate(hospital_files):
            col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
            
            with col1:
                st.markdown(f"""
                    <div class="info-box">
                        <strong>{file['filename']}</strong><br>
                        <small>Report: {file.get('first_name', 'N/A')} {file.get('last_name', 'N/A')} ({file['report_id']})</small><br>
                        <small>Size: {file['file_size_kb']} KB | Format: {file['file_format']} | Uploaded: {file['created_at'].strftime('%Y-%m-%d %H:%M')}</small><br>
                        <small>URL: <a href="{file['file_url']}" target="_blank">View File</a></small>
                    </div>
                """, unsafe_allow_html=True)
            
            with col2:
                # Download from URL
                st.download_button(
                    label="📥 Download",
                    data=requests.get(file['file_url']).content,
                    file_name=file['filename'],
                    mime="application/pdf",
                    key=f"download_{file['unique_filename']}_{i}",
                    use_container_width=True
                )
            
            with col3:
                # Preview with eye icon
                if create_eye_icon_button("Preview", f"cloud_storage_preview_{file['unique_filename']}_{i}"):
                    st.session_state.show_pdf_preview = True
                    st.session_state.preview_pdf_data = requests.get(file['file_url']).content
                    st.session_state.preview_pdf_title = f"Cloud Storage: {file['filename']}"
                    st.rerun()
            
            with col4:
                st.write(f"🔗 [Link]({file['file_url']})")
    else:
        st.markdown(f"""
            <div class="warning-box">
                No PDF reports stored in cloud yet for {hospital_name}.
            </div>
        """, unsafe_allow_html=True)

def show_login_page():
    """Show clean login page without headers"""
    st.markdown("""
        <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        </style>
    """, unsafe_allow_html=True)
    
    with st.container():
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown('<div class="login-container">', unsafe_allow_html=True)
            st.markdown('<h2 style="text-align: center;">🔐 Hospital Login</h2>', unsafe_allow_html=True)
            
            with st.form("login_form"):
                username = st.text_input("👤 Username", placeholder="Enter your username")
                password = st.text_input("🔒 Password", type="password", placeholder="Enter your password")
                
                col4, col5 = st.columns(2)
                with col4:
                    login_btn = st.form_submit_button("🚀 Login", use_container_width=True)
                with col5:
                    if st.form_submit_button("👤 Register", use_container_width=True):
                        st.session_state.show_register = True
                        st.rerun()
                
                # Hospital registration option
                st.markdown("---")
                if st.form_submit_button("🏥 Register Hospital", use_container_width=True):
                    st.session_state.show_hospital_registration = True
                    st.rerun()
                
                if login_btn:
                    if username and password:
                        user = authenticate_user(username, password)
                        if user:
                            st.session_state.user = user
                            st.rerun()
                        else:
                            st.error("Invalid username or password")
                    else:
                        st.error("Please enter both username and password")
            
            st.markdown('</div>', unsafe_allow_html=True)
def show_hospital_registration_page():
    """Show hospital registration page"""
    st.markdown('<h2 style="text-align: center;">🏥 Hospital Registration</h2>', unsafe_allow_html=True)
    
    with st.form("hospital_registration"):
        st.markdown("### Hospital Information")
        
        col1, col2 = st.columns(2)
        with col1:
            hospital_name = st.text_input("Hospital Name*", placeholder="Enter hospital name")
            hospital_code = st.text_input("Hospital Code*", placeholder="Unique code for hospital")
            phone_number = st.text_input("Phone Number*", placeholder="10-digit phone number")
        
        with col2:
            address = st.text_area("Address*", placeholder="Full hospital address")
            email = st.text_input("Email*", placeholder="Hospital email address")
        
        st.markdown("### Admin Account")
        
        col3, col4 = st.columns(2)
        with col3:
            admin_name = st.text_input("Admin Name*", placeholder="Full name of administrator")
            admin_username = st.text_input("Admin Username*", placeholder="Choose username")
        
        with col4:
            admin_mobile = st.text_input("Admin Mobile*", placeholder="10-digit mobile number")
            admin_password = st.text_input("Admin Password*", type="password", placeholder="6+ characters")
            confirm_password = st.text_input("Confirm Password*", type="password", placeholder="Confirm password")
        
        col5, col6 = st.columns(2)
        with col5:
            register_btn = st.form_submit_button("🏥 Register Hospital", use_container_width=True)
        with col6:
            if st.form_submit_button("← Back to Login", use_container_width=True):
                st.session_state.show_hospital_registration = False
                st.rerun()
        
        if register_btn:
            # Validate inputs
            errors = []
            
            if not all([hospital_name, hospital_code, address, phone_number, email]):
                errors.append("All hospital fields are required")
            
            if not all([admin_name, admin_username, admin_mobile, admin_password, confirm_password]):
                errors.append("All admin fields are required")
            
            if not validate_phone(phone_number):
                errors.append("Invalid phone number format (10 digits required)")
            
            if not validate_phone(admin_mobile):
                errors.append("Invalid mobile number format (10 digits required)")
            
            if not validate_email(email):
                errors.append("Invalid email format")
            
            if not validate_password(admin_password):
                errors.append("Password must be 6 or more characters")
            
            if admin_password != confirm_password:
                errors.append("Passwords do not match")
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                # Create hospital
                hospital_data = {
                    'hospital_name': hospital_name,
                    'hospital_code': hospital_code,
                    'address': address,
                    'phone_number': phone_number,
                    'email': email
                }
                
                hospital_id = create_hospital(hospital_data)
                
                if hospital_id:
                    # Create admin user
                    user_data = {
                        'hospital_id': hospital_id,
                        'username': admin_username,
                        'password': admin_password,
                        'user_type': 'admin',
                        'full_name': admin_name,
                        'mobile_number': admin_mobile
                    }
                    
                    if create_user(user_data):
                        st.success("Hospital and admin account created successfully! Please login.")
                        st.session_state.show_hospital_registration = False
                        st.rerun()
                    else:
                        st.error("Error creating admin account")
                else:
                    st.error("Error creating hospital. Hospital code may already exist.")

if __name__ == "__main__":
    main()     